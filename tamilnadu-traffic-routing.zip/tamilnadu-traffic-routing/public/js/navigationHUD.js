/**
 * navigationHUD.js - Heads-Up Display & Active Driving Controller with Maps Heads
 * Manages simulation telemetry, overhead highway gantry signboards (Map Heads),
 * rotating compass rose, and dynamic reroute prompts.
 */

class NavigationHUD {
  constructor(app) {
    this.app = app;
    this.hudElement = document.getElementById('navigation-hud');
    this.signboardElement = document.getElementById('overhead-highway-signboard');
    this.compassElement = document.getElementById('map-heading-compass');
    this.rerouteModal = document.getElementById('reroute-modal');

    this.dom = {
      roadName: document.getElementById('hud-road-name'),
      instruction: document.getElementById('hud-instruction'),
      speed: document.getElementById('hud-speed'),
      remainingDist: document.getElementById('hud-remaining-dist'),
      eta: document.getElementById('hud-eta'),
      progressBar: document.getElementById('hud-progress-bar'),
      speedButtons: document.querySelectorAll('.btn-speed'),
      stopButton: document.getElementById('btn-stop-simulation'),
      
      // Highway Signboard Map Heads DOM
      signHighwayRef: document.getElementById('sign-highway-ref'),
      signDestinations: document.getElementById('sign-destinations'),
      signNextExit: document.getElementById('sign-next-exit'),
      signLanesContainer: document.getElementById('sign-lanes-container'),
      signSpeedLimit: document.getElementById('sign-speed-limit'),
      signOsmType: document.getElementById('sign-osm-type'),

      // Compass Map Head DOM
      compassNeedle: document.getElementById('compass-needle'),
      compassDegrees: document.getElementById('compass-degrees'),
      compassCardinal: document.getElementById('compass-cardinal'),
      btnToggleCourseUp: document.getElementById('btn-toggle-course-up'),

      // Reroute modal DOM
      rerouteReason: document.getElementById('reroute-reason'),
      rerouteTimeSaved: document.getElementById('reroute-time-saved'),
      rerouteVia: document.getElementById('reroute-via'),
      btnAcceptReroute: document.getElementById('btn-accept-reroute'),
      btnDeclineReroute: document.getElementById('btn-decline-reroute')
    };

    this.pendingReroute = null;
    this.initEventListeners();
  }

  initEventListeners() {
    if (this.dom.stopButton) {
      this.dom.stopButton.addEventListener('click', () => {
        this.app.stopSimulation();
      });
    }

    if (this.dom.speedButtons) {
      this.dom.speedButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          this.dom.speedButtons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const speed = btn.getAttribute('data-speed');
          this.app.setSimulationSpeed(speed);
        });
      });
    }

    if (this.dom.btnToggleCourseUp) {
      this.dom.btnToggleCourseUp.addEventListener('click', () => {
        const isCourseUp = this.app.map.toggleCourseUp();
        this.dom.btnToggleCourseUp.classList.toggle('active', isCourseUp);
        this.app.showToast(isCourseUp ? '🧭 Course-Up Navigation Enabled' : '🧭 North-Up Fixed Map Enabled', 'info');
      });
    }

    if (this.compassElement) {
      this.compassElement.addEventListener('click', () => {
        // Reset map rotation or align to vehicle heading
        if (this.app.map.map) {
          this.app.map.map.setView(this.app.map.map.getCenter(), this.app.map.map.getZoom());
          this.app.showToast('Re-aligned Map Heading', 'info');
        }
      });
    }

    if (this.dom.btnAcceptReroute) {
      this.dom.btnAcceptReroute.addEventListener('click', () => {
        if (this.pendingReroute) {
          this.app.acceptReroute(this.pendingReroute);
          this.hideRerouteModal();
        }
      });
    }

    if (this.dom.btnDeclineReroute) {
      this.dom.btnDeclineReroute.addEventListener('click', () => {
        this.hideRerouteModal();
      });
    }
  }

  show() {
    if (this.hudElement) this.hudElement.classList.remove('hidden');
    if (this.signboardElement) this.signboardElement.classList.remove('hidden');
  }

  hide() {
    if (this.hudElement) this.hudElement.classList.add('hidden');
    if (this.signboardElement) this.signboardElement.classList.add('hidden');
    this.hideRerouteModal();
  }

  update(status, currentRoute) {
    if (!status.isActive) {
      this.hide();
      return;
    }

    this.show();

    // 1. Basic Navigation HUD metrics
    if (this.dom.speed) this.dom.speed.textContent = Math.round(status.currentSpeedKmh || 65);
    if (this.dom.remainingDist) this.dom.remainingDist.textContent = `${status.remainingDistanceKm} km`;
    if (this.dom.eta) this.dom.eta.textContent = status.formattedRemainingETA;
    if (this.dom.progressBar) this.dom.progressBar.style.width = `${status.progressPercent}%`;

    // 2. Compass Rose Map Head update
    const heading = status.headingDeg !== undefined ? status.headingDeg : 0;
    const compassDir = status.compassDirection || "N";

    if (this.dom.compassNeedle) {
      this.dom.compassNeedle.style.transform = `rotate(${heading}deg)`;
    }
    if (this.dom.compassDegrees) {
      this.dom.compassDegrees.textContent = `${heading}°`;
    }
    if (this.dom.compassCardinal) {
      this.dom.compassCardinal.textContent = compassDir;
    }

    // 3. Overhead Highway Signboard Map Head update
    if (status.mapHeadSignboard) {
      const sb = status.mapHeadSignboard;

      if (this.dom.signHighwayRef) this.dom.signHighwayRef.textContent = sb.highwayRef;
      if (this.dom.signDestinations) this.dom.signDestinations.textContent = sb.destinationTowns.join(" / ").toUpperCase();
      if (this.dom.signNextExit) this.dom.signNextExit.textContent = `⬈ ${sb.nextExitName} (${sb.distToNextJunctionKm} km)`;
      if (this.dom.signSpeedLimit) this.dom.signSpeedLimit.textContent = sb.speedLimitKmh;
      if (this.dom.signOsmType) this.dom.signOsmType.textContent = `OSM: ${sb.osmHighwayType}`;

      // Dynamic Lane Guidance Arrows Head
      if (this.dom.signLanesContainer && sb.laneGuidance) {
        this.dom.signLanesContainer.innerHTML = sb.laneGuidance.map(g => `
          <div class="lane-arrow ${g.type === 'exit' ? 'lane-exit' : 'lane-thru'} ${g.active ? 'active-lane' : ''}">
            <i class="fa-solid ${g.type === 'exit' ? 'fa-arrow-up-right-from-square' : 'fa-arrow-up'}"></i>
          </div>
        `).join('');
      }

      if (this.dom.roadName) this.dom.roadName.textContent = sb.roadName;
      if (this.dom.instruction) this.dom.instruction.textContent = `Continue on ${sb.highwayRef} towards ${sb.destinationTowns[0]}`;
    }

    if (status.arrived) {
      if (this.dom.instruction) this.dom.instruction.textContent = "🎉 Destination reached!";
      if (this.dom.remainingDist) this.dom.remainingDist.textContent = "0 km";
      if (this.dom.eta) this.dom.eta.textContent = "Arrived";
      this.app.showToast("Journey Completed! Arrived at destination in Tamil Nadu.", "success");
    }
  }

  showReroutePrompt(alertData) {
    this.pendingReroute = alertData.newRoute;
    if (this.dom.rerouteReason) this.dom.rerouteReason.textContent = alertData.reason;
    if (this.dom.rerouteTimeSaved) this.dom.rerouteTimeSaved.textContent = alertData.formattedTimeSaved;
    if (this.dom.rerouteVia) this.dom.rerouteVia.textContent = `Via ${alertData.newRoute.pathNodeNames.slice(1, 3).join(' → ')}`;
    if (this.rerouteModal) this.rerouteModal.classList.remove('hidden');

    this.app.showToast(`⚡ Faster route found! Save ${Math.round(alertData.timeSavedMin)} mins!`, 'warning');
  }

  hideRerouteModal() {
    if (this.rerouteModal) this.rerouteModal.classList.add('hidden');
    this.pendingReroute = null;
  }
}

window.NavigationHUD = NavigationHUD;
