/**
 * voiceAssistant.js - Live Traffic Voice Assistant & Speech Synthesis Engine
 * Provides spoken traffic announcements, turn-by-turn speech guidance,
 * audio chime cues, and on-demand live traffic voice bulletins in English & Tamil.
 */

class TrafficVoiceAssistant {
  constructor() {
    this.synth = window.speechSynthesis || null;
    this.audioCtx = null;
    this.isEnabled = true;
    this.language = 'en-IN'; // 'en-IN' (English India) or 'ta-IN' (Tamil)
    this.speechRate = 1.0;
    this.speechPitch = 1.0;
    this.speechVolume = 1.0;
    this.voices = [];
    this.selectedVoice = null;
    this.lastSpokenText = "";
    this.lastSpokenTimestamp = 0;
    this.minRepeatIntervalMs = 7000; // Prevent spamming duplicate messages

    this.dom = {
      voiceToggleBtn: document.getElementById('btn-voice-toggle'),
      voiceBriefingBtn: document.getElementById('btn-voice-briefing'),
      speechBanner: document.getElementById('voice-speech-banner'),
      speechText: document.getElementById('voice-speech-text'),
      waveformBars: document.querySelectorAll('.waveform-bar')
    };

    this.initAudioContext();
    this.initVoices();
    this.setupEventListeners();
  }

  initAudioContext() {
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    } catch (e) {
      console.warn("Web Audio Context not supported:", e);
    }
  }

  initVoices() {
    if (!this.synth) return;

    const loadVoices = () => {
      this.voices = this.synth.getVoices();
      this.pickOptimalVoice();
    };

    loadVoices();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = loadVoices;
    }
  }

  pickOptimalVoice() {
    if (!this.voices || this.voices.length === 0) return;

    if (this.language === 'ta-IN') {
      const tamilVoice = this.voices.find(v => v.lang.startsWith('ta') || v.name.toLowerCase().includes('tamil'));
      if (tamilVoice) {
        this.selectedVoice = tamilVoice;
        return;
      }
    }

    // Default to Indian English or high-quality English voice
    const indianEnglish = this.voices.find(v => v.lang === 'en-IN' || v.name.includes('India'));
    const englishVoice = this.voices.find(v => v.lang.startsWith('en'));

    this.selectedVoice = indianEnglish || englishVoice || this.voices[0];
  }

  setupEventListeners() {
    if (this.dom.voiceToggleBtn) {
      this.dom.voiceToggleBtn.addEventListener('click', () => {
        this.toggleVoice();
      });
    }

    if (this.dom.voiceBriefingBtn) {
      this.dom.voiceBriefingBtn.addEventListener('click', () => {
        this.speakLiveTrafficBriefing();
      });
    }
  }

  toggleVoice(forceState = null) {
    this.isEnabled = forceState !== null ? forceState : !this.isEnabled;
    if (this.dom.voiceToggleBtn) {
      this.dom.voiceToggleBtn.classList.toggle('muted', !this.isEnabled);
      this.dom.voiceToggleBtn.innerHTML = this.isEnabled
        ? '<i class="fa-solid fa-volume-high"></i> <span>Voice On</span>'
        : '<i class="fa-solid fa-volume-xmark"></i> <span>Muted</span>';
    }

    if (!this.isEnabled && this.synth) {
      this.synth.cancel();
      this.hideSpeechBanner();
    } else if (this.isEnabled) {
      this.playChime(660, 0.12);
      this.speak("Live traffic voice assistant active.", "நேரலை போக்குவரத்து குரல் உதவியாளர் இயக்கப்பட்டது.");
    }

    return this.isEnabled;
  }

  setLanguage(langCode) {
    this.language = langCode;
    this.pickOptimalVoice();
  }

  /**
   * Synthesize a gentle navigation chime tone using Web Audio API
   */
  playChime(frequency = 587.33, durationSec = 0.15) {
    if (!this.audioCtx || !this.isEnabled) return;

    try {
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }

      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, this.audioCtx.currentTime);
      // Gentle decay curve
      gain.gain.setValueAtTime(0.2, this.audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + durationSec);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start();
      osc.stop(this.audioCtx.currentTime + durationSec);
    } catch (e) {
      // Ignore audio context exceptions
    }
  }

  /**
   * Main speech output method: speaks text aloud and updates on-screen voice saying banner
   */
  speak(textEnglish, textTamil = null, priority = false) {
    if (!this.isEnabled || !this.synth) return;

    const now = Date.now();
    const textToSpeak = (this.language === 'ta-IN' && textTamil) ? textTamil : textEnglish;

    // Avoid duplicate repetitive announcements within cooldown window unless priority
    if (!priority && textToSpeak === this.lastSpokenText && (now - this.lastSpokenTimestamp) < this.minRepeatIntervalMs) {
      return;
    }

    this.lastSpokenText = textToSpeak;
    this.lastSpokenTimestamp = now;

    // Interrupt current non-priority speech if new instruction comes in
    this.synth.cancel();

    // Play alert chime
    this.playChime(priority ? 784 : 587, 0.15);

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = this.speechRate;
    utterance.pitch = this.speechPitch;
    utterance.volume = this.speechVolume;

    if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
    }

    // Show visual speech banner with live animated equalizer
    this.showSpeechBanner(textToSpeak);

    utterance.onend = () => {
      this.hideSpeechBanner();
    };

    utterance.onerror = () => {
      this.hideSpeechBanner();
    };

    this.synth.speak(utterance);
  }

  showSpeechBanner(text) {
    if (this.dom.speechBanner && this.dom.speechText) {
      this.dom.speechText.textContent = text;
      this.dom.speechBanner.classList.remove('hidden');
      if (this.dom.waveformBars) {
        this.dom.waveformBars.forEach(b => b.classList.add('animating'));
      }
    }
  }

  hideSpeechBanner() {
    setTimeout(() => {
      if (this.dom.speechBanner && !this.synth.speaking) {
        this.dom.speechBanner.classList.add('hidden');
        if (this.dom.waveformBars) {
          this.dom.waveformBars.forEach(b => b.classList.remove('animating'));
        }
      }
    }, 1200);
  }

  /**
   * Spoken Traffic Condition Alert Generator
   * Triggered during mid-journey driving simulation
   */
  announceTrafficConditions(speedKmh, segment, congestionFactor) {
    if (congestionFactor >= 2.3) {
      this.speak(
        `Heavy traffic ahead on ${segment.name}. Speed dropped to ${Math.round(speedKmh)} kilometers per hour. Delay expected.`,
        `${segment.name} சாலையில் கடுமையான போக்குவரத்து நெரிசல். வேகம் குறைந்துள்ளது.`,
        true
      );
    } else if (congestionFactor >= 1.6) {
      this.speak(
        `Moderate slowdown on ${segment.name}. Flowing at ${Math.round(speedKmh)} kilometers per hour.`,
        `${segment.name} சாலையில் மிதமான போக்குவரத்து நெரிசல் காணப்படுகிறது.`
      );
    } else if (congestionFactor <= 1.15 && speedKmh >= 80) {
      this.speak(
        `Clear road ahead on ${segment.name}. Speed limit is ${segment.freeFlowSpeedKmh} kilometers per hour.`,
        `முன்னால் சாலை சீராக உள்ளது. போக்குவரத்து நெரிசல் இல்லை.`
      );
    }
  }

  /**
   * Spoken Proactive Reroute Alert
   */
  announceRerouteAlert(alertData) {
    const minsSaved = Math.round(alertData.timeSavedMin);
    const viaText = alertData.newRoute.pathNodeNames.slice(1, 3).join(' and ');
    this.speak(
      `Faster route found! Save ${minsSaved} minutes by taking the bypass via ${viaText}. Reroute recommended.`,
      `விரைவான மாற்றுப் பாதை கண்டுபிடிக்கப்பட்டது! ${minsSaved} நிமிடங்கள் மிச்சமாகும். மாற்றுப் பாதையைத் தேர்ந்தெடுக்கவும்.`,
      true
    );
  }

  /**
   * Spoken Incident / Hazard Warning
   */
  announceIncident(incident) {
    this.speak(
      `Caution: ${incident.title} reported ahead. Extra delay of approximately ${incident.delayMin} minutes.`,
      `எச்சரிக்கை: முன்னால் ${incident.title} ஏற்பட்டுள்ளது. கூடுதல் தாமதம் ஏற்படலாம்.`,
      true
    );
  }

  /**
   * Spoken State-of-the-State Traffic Bulletin
   * On-demand broadcast of live Tamil Nadu traffic conditions
   */
  speakLiveTrafficBriefing(networkData = null) {
    const timeOfDay = new Date().getHours() < 12 ? "Good morning" : (new Date().getHours() < 17 ? "Good afternoon" : "Good evening");
    
    let scenarioText = "Standard free-flow conditions prevail across the central NH44 corridor from Salem to Madurai.";
    if (window.app && window.app.network) {
      const activeIncidents = window.app.network.incidents || [];
      if (activeIncidents.length > 0) {
        const topInc = activeIncidents[0];
        scenarioText = `Heads up: ${topInc.title} is causing delays of ${topInc.delayMin} minutes. Paranur toll plaza on GST Road is seeing queues.`;
      }
    }

    const fullBroadcast = `${timeOfDay}! Here is your Tamil Nadu live road briefing. ${scenarioText} All FASTag electronic lanes are operational. Travel safely!`;
    const tamilBroadcast = `வணக்கம்! இது உங்கள் நேரலை தமிழ்நாடு போக்குவரத்து அறிக்கை. தேசிய நெடுஞ்சாலைகளில் போக்குவரத்து கண்காணிக்கப்படுகிறது. சுங்கச்சாவடிகளில் நெரிசல் சீராக உள்ளது. பாதுகாப்பாக பயணிக்கவும்!`;

    this.speak(fullBroadcast, tamilBroadcast, true);
  }
}

window.TrafficVoiceAssistant = TrafficVoiceAssistant;
