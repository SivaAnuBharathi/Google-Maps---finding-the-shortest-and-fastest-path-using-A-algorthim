/**
 * metricsChart.js - Real-Time Telemetry & Surgical Invalidation Observer
 * Keeps track of cache performance, computation speedups, and live streaming metrics.
 */

class MetricsTelemetryManager {
  constructor() {
    this.dom = {
      tickerProbes: document.getElementById('ticker-probes'),
      tickerCacheHit: document.getElementById('ticker-cache-hit'),
      tickerHazards: document.getElementById('ticker-hazards'),
      tickerScenario: document.getElementById('ticker-scenario'),

      // Modal telemetry metrics
      metricCacheHitRate: document.getElementById('metric-cache-hit-rate'),
      metricHitsMisses: document.getElementById('metric-cache-hits-misses'),
      metricSavedCpu: document.getElementById('metric-saved-cpu'),
      metricInvalidations: document.getElementById('metric-invalidations'),
      metricProbes: document.getElementById('metric-probes'),
      invalidationLogTbody: document.getElementById('invalidation-log-tbody')
    };
  }

  updateTelemetry(telemetry) {
    if (!telemetry) return;

    const cache = telemetry.cache;
    const traffic = telemetry.traffic;

    // 1. Update Top Ticker
    if (traffic) {
      if (this.dom.tickerProbes) {
        this.dom.tickerProbes.textContent = `${traffic.probesProcessed.toLocaleString()} probes`;
      }
      if (this.dom.tickerHazards) {
        this.dom.tickerHazards.textContent = traffic.totalIncidents;
      }
      if (this.dom.tickerScenario) {
        const scenarioNames = {
          normal: "Normal Traffic",
          chennai_rush_hour: "Chennai Rush Hour",
          festival_exodus: "Pongal / Diwali Exodus",
          monsoon_flooding: "Monsoon Inundation"
        };
        this.dom.tickerScenario.textContent = scenarioNames[traffic.activeScenario] || traffic.activeScenario;
      }
    }

    if (cache) {
      if (this.dom.tickerCacheHit) {
        this.dom.tickerCacheHit.textContent = cache.hitRate;
      }
      if (this.dom.metricCacheHitRate) {
        this.dom.metricCacheHitRate.textContent = cache.hitRate;
      }
      if (this.dom.metricHitsMisses) {
        this.dom.metricHitsMisses.textContent = `${cache.hits} hits / ${cache.misses} misses`;
      }
      if (this.dom.metricSavedCpu) {
        this.dom.metricSavedCpu.textContent = `${cache.totalSavedTimeMs} ms`;
      }
      if (this.dom.metricInvalidations) {
        this.dom.metricInvalidations.textContent = cache.invalidations;
      }

      // Render recent surgical invalidation log table
      if (this.dom.invalidationLogTbody && cache.recentInvalidations) {
        if (cache.recentInvalidations.length === 0) {
          this.dom.invalidationLogTbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No cache invalidations yet.</td></tr>';
        } else {
          this.dom.invalidationLogTbody.innerHTML = cache.recentInvalidations.map(log => `
            <tr>
              <td><code>${log.timestamp}</code></td>
              <td><b>${log.routeKey}</b></td>
              <td><span class="text-amber">${log.reason}</span></td>
            </tr>
          `).join('');
        }
      }
    }

    if (traffic && this.dom.metricProbes) {
      this.dom.metricProbes.textContent = traffic.probesProcessed.toLocaleString();
    }
  }
}

window.MetricsTelemetryManager = MetricsTelemetryManager;
