/**
 * app.js - Master Orchestrator for Tamil Nadu Dynamic Routing & Pathfinding Application
 * Coordinates network loading, Leaflet live map, WebSockets, route cards,
 * simulation HUD, and Traffic Chaos Studio.
 */

class App {
  constructor() {
    this.network = null;
    this.presets = null;
    this.currentRouteResult = null;
    this.selectedRouteIndex = 0;
    this.activeTripStatus = null;
    this.ws = null;

    // Sub-controllers
    this.map = new LiveMapManager();
    this.hud = new NavigationHUD(this);
    this.telemetry = new MetricsTelemetryManager();

    // DOM Elements
    this.dom = {
      selectOrigin: document.getElementById('select-origin'),
      selectDestination: document.getElementById('select-destination'),
      btnSwap: document.getElementById('btn-swap-locations'),
      btnFindRoutes: document.getElementById('btn-find-routes'),
      btnClear: document.getElementById('btn-clear-routes'),
      presetsChips: document.getElementById('presets-chips'),
      
      routeResultsContainer: document.getElementById('route-results-container'),
      emptyRoutesPlaceholder: document.getElementById('empty-routes-placeholder'),
      routeCardsList: document.getElementById('route-cards-list'),
      selectedRouteDetails: document.getElementById('selected-route-details'),

      btnStartSimulation: document.getElementById('btn-start-simulation'),
      toggleDirectionsBtn: document.getElementById('toggle-directions-btn'),
      directionsBody: document.getElementById('directions-body'),
      directionsList: document.getElementById('directions-list'),
      directionsStepCount: document.getElementById('directions-step-count'),

      // Economics DOM
      econFuelCost: document.getElementById('econ-fuel-cost'),
      econFuelLiters: document.getElementById('econ-fuel-liters'),
      econTollCost: document.getElementById('econ-toll-cost'),
      econTollCount: document.getElementById('econ-toll-count'),
      econCo2: document.getElementById('econ-co2'),

      // Layer toggles
      layerTrafficToggle: document.getElementById('layer-traffic-toggle'),
      layerTollsToggle: document.getElementById('layer-tolls-toggle'),
      layerHazardsToggle: document.getElementById('layer-hazards-toggle'),
      layerNodesToggle: document.getElementById('layer-nodes-toggle'),

      // Studio Modal
      btnChaosControl: document.getElementById('btn-chaos-control'),
      modalTrafficStudio: document.getElementById('modal-traffic-studio'),
      selectIncidentEdge: document.getElementById('select-incident-edge'),
      formInjectIncident: document.getElementById('form-inject-incident'),
      activeIncidentsList: document.getElementById('active-incidents-list'),
      activeHazardsCount: document.getElementById('active-hazards-count'),

      // Insights Modal
      btnInsights: document.getElementById('btn-insights'),
      modalInsights: document.getElementById('modal-insights'),

      // Theme toggle
      btnThemeToggle: document.getElementById('btn-theme-toggle'),
      toastContainer: document.getElementById('toast-container')
    };
  }

  async init() {
    this.map.init('leaflet-map', (node) => this.onMapNodeClicked(node));
    this.setupEventListeners();
    await this.loadInitialData();
    this.connectWebSocket();
    this.startTelemetryPoller();
  }

  async loadInitialData() {
    try {
      const [networkRes, presetsRes] = await Promise.all([
        fetch('/api/network').then(r => r.json()),
        fetch('/api/presets').then(r => r.json())
      ]);

      this.network = networkRes;
      this.presets = presetsRes;

      this.populateNodeSelects();
      this.populatePresets();
      this.populateIncidentEdges();

      // Render base road network and incidents onto map
      this.map.renderNetwork(this.network.nodes, this.network.edges);
      this.map.renderIncidents(this.network.incidents);
      this.renderActiveIncidentsList(this.network.incidents);

      // Default route: Chennai Central to Madurai
      this.dom.selectOrigin.value = 'chennai_central';
      this.dom.selectDestination.value = 'madurai';
      this.findRoutes();
    } catch (err) {
      console.error('Failed to load initial data:', err);
      this.showToast('Error loading road network data.', 'warning');
    }
  }

  populateNodeSelects() {
    const sortedNodes = [...this.network.nodes].sort((a, b) => a.name.localeCompare(b.name));

    const html = sortedNodes.map(n => `
      <option value="${n.id}">${n.name} (${n.district})</option>
    `).join('');

    this.dom.selectOrigin.innerHTML = html;
    this.dom.selectDestination.innerHTML = html;
  }

  populatePresets() {
    if (!this.presets || !this.presets.presets) return;

    this.dom.presetsChips.innerHTML = this.presets.presets.map(p => `
      <button class="preset-chip" data-from="${p.from}" data-to="${p.to}" title="${p.description}">
        ${p.title.split('(')[0]}
      </button>
    `).join('');

    this.dom.presetsChips.querySelectorAll('.preset-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const from = chip.getAttribute('data-from');
        const to = chip.getAttribute('data-to');
        this.dom.selectOrigin.value = from;
        this.dom.selectDestination.value = to;
        this.findRoutes();
      });
    });
  }

  populateIncidentEdges() {
    const uniqueEdges = new Map();
    for (const edge of this.network.edges) {
      const canonicalKey = [edge.from, edge.to].sort().join('-');
      if (!uniqueEdges.has(canonicalKey)) {
        uniqueEdges.set(canonicalKey, edge);
      }
    }

    const sortedEdges = Array.from(uniqueEdges.values()).sort((a, b) => a.name.localeCompare(b.name));
    this.dom.selectIncidentEdge.innerHTML = sortedEdges.map(e => `
      <option value="${e.id}">${e.name} (${e.category})</option>
    `).join('');
  }

  setupEventListeners() {
    // Swap locations
    this.dom.btnSwap.addEventListener('click', () => {
      const tmp = this.dom.selectOrigin.value;
      this.dom.selectOrigin.value = this.dom.selectDestination.value;
      this.dom.selectDestination.value = tmp;
      this.findRoutes();
    });

    // Find routes
    this.dom.btnFindRoutes.addEventListener('click', () => this.findRoutes());

    // Clear routes
    this.dom.btnClear.addEventListener('click', () => this.clearRoute());

    // Start Simulation
    this.dom.btnStartSimulation.addEventListener('click', () => this.startSimulation());

    // Toggle Directions
    this.dom.toggleDirectionsBtn.addEventListener('click', () => {
      this.dom.directionsBody.classList.toggle('hidden');
      const icon = this.dom.toggleDirectionsBtn.querySelector('.toggle-icon');
      if (icon) {
        icon.classList.toggle('fa-chevron-down');
        icon.classList.toggle('fa-chevron-up');
      }
    });

    // Layer toggles
    this.dom.layerTrafficToggle.addEventListener('change', (e) => {
      this.map.toggleLayer('baseRoads', e.target.checked);
    });
    this.dom.layerTollsToggle.addEventListener('change', (e) => {
      this.map.toggleLayer('tolls', e.target.checked);
    });
    this.dom.layerHazardsToggle.addEventListener('change', (e) => {
      this.map.toggleLayer('hazards', e.target.checked);
    });
    this.dom.layerNodesToggle.addEventListener('change', (e) => {
      this.map.toggleLayer('nodes', e.target.checked);
    });

    // Modals
    this.dom.btnChaosControl.addEventListener('click', () => {
      this.dom.modalTrafficStudio.classList.remove('hidden');
    });

    this.dom.btnInsights.addEventListener('click', () => {
      this.dom.modalInsights.classList.remove('hidden');
      this.fetchTelemetry();
    });

    document.querySelectorAll('.modal-close-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const modalId = btn.getAttribute('data-close');
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.add('hidden');
      });
    });

    // Scenario cards in Traffic Studio
    document.querySelectorAll('.scenario-card').forEach(card => {
      card.addEventListener('click', async () => {
        document.querySelectorAll('.scenario-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        const scenarioId = card.getAttribute('data-scenario');
        await this.switchTrafficScenario(scenarioId);
      });
    });

    // Inject Incident Form
    this.dom.formInjectIncident.addEventListener('submit', async (e) => {
      e.preventDefault();
      await this.injectIncident();
    });

    // Theme toggle
    this.dom.btnThemeToggle.addEventListener('click', () => {
      const isLight = document.body.classList.toggle('light-theme');
      this.dom.btnThemeToggle.innerHTML = isLight ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
      this.map.setBasemap(isLight ? 'cartoPositron' : 'cartoDark');
    });

    // Basemap Switcher Map Heads (OSM Providers)
    document.querySelectorAll('.basemap-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('.basemap-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        const basemapKey = pill.getAttribute('data-basemap');
        this.map.setBasemap(basemapKey);
        this.showToast(`Switched Basemap to ${pill.textContent.trim()}`, 'info');
      });
    });

    // Smart Map Head Search Autocomplete
    const searchInput = document.getElementById('map-head-search-input');
    const searchResults = document.getElementById('map-head-search-results');
    const clearSearchBtn = document.getElementById('map-head-search-clear');

    if (searchInput && searchResults) {
      searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim().toLowerCase();
        if (!query) {
          searchResults.classList.add('hidden');
          if (clearSearchBtn) clearSearchBtn.classList.add('hidden');
          return;
        }
        if (clearSearchBtn) clearSearchBtn.classList.remove('hidden');

        const matchedNodes = (this.network ? this.network.nodes : []).filter(n =>
          n.name.toLowerCase().includes(query) ||
          n.district.toLowerCase().includes(query)
        ).slice(0, 5);

        const matchedEdges = (this.network ? this.network.edges : []).filter(ed =>
          ed.name.toLowerCase().includes(query) ||
          (ed.highwayRef && ed.highwayRef.toLowerCase().includes(query))
        ).slice(0, 4);

        if (matchedNodes.length === 0 && matchedEdges.length === 0) {
          searchResults.innerHTML = '<div style="padding:10px; font-size:12px; color:#94a3b8;">No matching locations found in Tamil Nadu.</div>';
          searchResults.classList.remove('hidden');
          return;
        }

        let html = '';
        matchedNodes.forEach(node => {
          html += `
            <div class="search-item" data-type="node" data-id="${node.id}">
              <div>
                <div class="search-item-title"><i class="fa-solid fa-location-dot text-primary"></i> ${node.name}</div>
                <div class="search-item-sub">${node.district} District | OSM Node</div>
              </div>
              <button class="btn btn-ghost btn-sm set-origin-btn" title="Set as Journey Origin">Set Origin</button>
            </div>
          `;
        });

        matchedEdges.forEach(edge => {
          html += `
            <div class="search-item" data-type="edge" data-id="${edge.id}">
              <div>
                <div class="search-item-title"><i class="fa-solid fa-road text-amber"></i> ${edge.name}</div>
                <div class="search-item-sub">${edge.highwayRef || 'OSM Highway'} | ${edge.category}</div>
              </div>
              <span style="font-size:11px; color:#10b981; font-weight:700;">${edge.distanceKm} km</span>
            </div>
          `;
        });

        searchResults.innerHTML = html;
        searchResults.classList.remove('hidden');

        searchResults.querySelectorAll('.search-item').forEach(item => {
          item.addEventListener('click', (ev) => {
            const type = item.getAttribute('data-type');
            const id = item.getAttribute('data-id');

            if (ev.target.classList.contains('set-origin-btn')) {
              ev.stopPropagation();
              this.dom.selectOrigin.value = id;
              this.showToast(`Set Origin: ${item.querySelector('.search-item-title').textContent.trim()}`, 'info');
              searchResults.classList.add('hidden');
              return;
            }

            if (type === 'node') {
              const node = this.network.nodes.find(n => n.id === id);
              if (node) {
                this.map.map.flyTo([node.lat, node.lng], 11, { duration: 1.2 });
                this.showToast(`Navigated to ${node.name}`, 'info');
              }
            } else if (type === 'edge') {
              const edge = this.network.edges.find(ed => ed.id === id);
              if (edge && edge.geometry && edge.geometry.length > 0) {
                const mid = edge.geometry[Math.floor(edge.geometry.length / 2)];
                this.map.map.flyTo(mid, 10, { duration: 1.2 });
                this.showToast(`Inspecting ${edge.name}`, 'info');
              }
            }
            searchResults.classList.add('hidden');
          });
        });
      });

      if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', () => {
          searchInput.value = '';
          searchResults.classList.add('hidden');
          clearSearchBtn.classList.add('hidden');
        });
      }

      document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
          searchResults.classList.add('hidden');
        }
      });
    }
  }

  onMapNodeClicked(node) {
    if (!this.dom.selectOrigin.value) {
      this.dom.selectOrigin.value = node.id;
      this.showToast(`Set Origin: ${node.name}`, 'info');
    } else {
      this.dom.selectDestination.value = node.id;
      this.showToast(`Set Destination: ${node.name}`, 'info');
      this.findRoutes();
    }
  }

  async findRoutes() {
    const from = this.dom.selectOrigin.value;
    const to = this.dom.selectDestination.value;

    if (!from || !to) {
      this.showToast('Please select both Origin and Destination.', 'warning');
      return;
    }

    if (from === to) {
      this.showToast('Origin and Destination cannot be the same.', 'warning');
      return;
    }

    this.dom.btnFindRoutes.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Calculating...';

    try {
      const res = await fetch(`/api/route?from=${from}&to=${to}&mode=all`);
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to calculate route');
      }

      this.currentRouteResult = data;
      this.selectedRouteIndex = 0;

      this.renderRouteCards(data);
      this.map.renderRoutes(data, 0);

      const cacheMsg = data.isFromCache
        ? `⚡ Instant Cache Hit (${data.queryTimeMs} ms)`
        : `⚙️ Dynamic Graph Pathfinding (${data.queryTimeMs} ms)`;
      this.showToast(cacheMsg, data.isFromCache ? 'success' : 'info');

      if (data.cacheStats) {
        this.telemetry.updateTelemetry({ cache: data.cacheStats });
      }
    } catch (err) {
      this.showToast(err.message, 'warning');
    } finally {
      this.dom.btnFindRoutes.innerHTML = '<i class="fa-solid fa-magnifying-glass-location"></i> Find Routes';
    }
  }

  renderRouteCards(result) {
    this.dom.emptyRoutesPlaceholder.classList.add('hidden');
    this.dom.routeCardsList.classList.remove('hidden');
    this.dom.selectedRouteDetails.classList.remove('hidden');

    const allRoutes = [];
    if (result.primary) {
      allRoutes.push(result.primary);
      if (result.alternatives && result.alternatives.length > 0) {
        allRoutes.push(...result.alternatives);
      }
      if (result.shortest && result.shortest.edgeIds.join() !== result.primary.edgeIds.join()) {
        allRoutes.push(result.shortest);
      }
    } else {
      allRoutes.push(result);
    }

    this.dom.routeCardsList.innerHTML = allRoutes.map((r, idx) => {
      const isSelected = idx === this.selectedRouteIndex;
      const badgeClass = r.badge === 'RECOMMENDED' ? 'badge-recommended' : (r.badge === 'SHORTEST' ? 'badge-shortest' : 'badge-alt');

      const delayBadge = r.trafficDelayMin > 0
        ? `<span class="route-delay-badge">+${Math.round(r.trafficDelayMin)}m delay</span>`
        : '';

      return `
        <div class="route-card ${isSelected ? 'active' : ''}" data-index="${idx}">
          <div class="route-card-header">
            <span class="route-badge ${badgeClass}">${r.badge || r.routeTag}</span>
            <span class="route-dist">${r.totalDistanceKm} km</span>
          </div>
          <div class="route-card-metrics">
            <span class="route-eta">${r.formattedETA}</span>
            ${delayBadge}
          </div>
          <div class="route-corridor-name">
            <i class="fa-solid fa-road"></i> Via ${r.pathNodeNames.slice(1, 3).join(' → ')}
          </div>
        </div>
      `;
    }).join('');

    // Attach card click handlers
    this.dom.routeCardsList.querySelectorAll('.route-card').forEach(card => {
      card.addEventListener('click', () => {
        const idx = parseInt(card.getAttribute('data-index'), 10);
        this.selectRoute(idx);
      });
    });

    this.updateRouteDetails(allRoutes[this.selectedRouteIndex]);
  }

  selectRoute(index) {
    this.selectedRouteIndex = index;
    const cards = this.dom.routeCardsList.querySelectorAll('.route-card');
    cards.forEach((c, idx) => {
      c.classList.toggle('active', idx === index);
    });

    const allRoutes = this.getAllRoutesList();
    const selected = allRoutes[index] || allRoutes[0];

    this.map.renderRoutes(this.currentRouteResult, index);
    this.updateRouteDetails(selected);
  }

  getAllRoutesList() {
    const res = this.currentRouteResult;
    if (!res) return [];
    if (!res.primary) return [res];

    const list = [res.primary];
    if (res.alternatives) list.push(...res.alternatives);
    if (res.shortest && res.shortest.edgeIds.join() !== res.primary.edgeIds.join()) {
      list.push(res.shortest);
    }
    return list;
  }

  updateRouteDetails(route) {
    if (!route) return;

    // Economics
    if (route.economics) {
      this.dom.econFuelCost.textContent = `₹${route.economics.estimatedFuelCostInr.toLocaleString()}`;
      this.dom.econFuelLiters.textContent = `${route.economics.fuelLiters} L Petrol`;
      this.dom.econTollCost.textContent = `₹${route.economics.estimatedTollCostInr.toLocaleString()}`;
      this.dom.econTollCount.textContent = `${route.economics.tollCount} FASTag Tolls`;
      this.dom.econCo2.textContent = `${route.economics.co2Kg} kg`;
    }

    // Turn by turn directions
    if (route.directions) {
      this.dom.directionsStepCount.textContent = route.directions.length;
      this.dom.directionsList.innerHTML = route.directions.map(d => `
        <li class="direction-item">
          <div class="direction-step-name">${d.instruction}</div>
          <div class="direction-sub">${d.distanceKm > 0 ? `${d.distanceKm} km | ` : ''}${d.cumulativeKm} km total</div>
        </li>
      `).join('');
    }
  }

  async startSimulation() {
    const allRoutes = this.getAllRoutesList();
    const routeToDrive = allRoutes[this.selectedRouteIndex];

    if (!routeToDrive) return;

    try {
      const res = await fetch('/api/simulation/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ route: routeToDrive })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast('Starting Mid-Journey Drive Simulation...', 'success');
        this.hud.show();
      }
    } catch (err) {
      this.showToast('Failed to start simulation', 'warning');
    }
  }

  async stopSimulation() {
    await fetch('/api/simulation/stop', { method: 'POST' });
    this.hud.hide();
    this.map.removeVehicle();
    this.showToast('Navigation simulation ended.', 'info');
  }

  async setSimulationSpeed(multiplier) {
    await fetch('/api/simulation/speed', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ multiplier })
    });
  }

  async acceptReroute(newRoute) {
    try {
      const res = await fetch('/api/simulation/reroute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newRoute })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast('Reroute Accepted! New trajectory active.', 'success');
        // Update current route result and map
        this.currentRouteResult.primary = newRoute;
        this.renderRouteCards(this.currentRouteResult);
        this.map.renderRoutes(this.currentRouteResult, 0);
      }
    } catch (e) {
      console.error(e);
    }
  }

  async switchTrafficScenario(scenarioId) {
    try {
      const res = await fetch('/api/traffic/scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenarioId })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(`Traffic Scenario updated: ${scenarioId}`, 'info');
        // Re-evaluate current active route under new traffic conditions
        if (this.currentRouteResult) {
          this.findRoutes();
        }
      }
    } catch (err) {
      this.showToast('Error switching scenario', 'warning');
    }
  }

  async injectIncident() {
    const edgeId = this.dom.selectIncidentEdge.value;
    const type = document.getElementById('select-incident-type').value;
    const title = document.getElementById('input-incident-title').value;
    const delayMin = parseInt(document.getElementById('input-incident-delay').value, 10);

    const edge = this.network.edges.find(e => e.id === edgeId);
    let lat = 11.5, lng = 78.5;
    if (edge && edge.geometry && edge.geometry.length > 0) {
      const mid = edge.geometry[Math.floor(edge.geometry.length / 2)];
      lat = mid[0];
      lng = mid[1];
    }

    try {
      const res = await fetch('/api/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ edgeId, type, title, delayMin, lat, lng })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(`Injected Hazard: ${title} (+${delayMin}m delay)`, 'warning');
        this.dom.modalTrafficStudio.classList.add('hidden');
        this.dom.formInjectIncident.reset();
        // Refresh routes
        this.findRoutes();
      }
    } catch (err) {
      this.showToast('Failed to inject incident', 'warning');
    }
  }

  async removeIncident(incidentId) {
    try {
      await fetch(`/api/incidents/${incidentId}`, { method: 'DELETE' });
      this.showToast('Hazard removed from Tamil Nadu network.', 'info');
      this.findRoutes();
    } catch (e) {
      console.error(e);
    }
  }

  renderActiveIncidentsList(incidents) {
    this.dom.activeHazardsCount.textContent = incidents.length;
    if (incidents.length === 0) {
      this.dom.activeIncidentsList.innerHTML = '<div class="text-muted" style="font-size: 12px; padding: 10px;">No active hazards reported.</div>';
      return;
    }

    this.dom.activeIncidentsList.innerHTML = incidents.map(inc => `
      <div class="hazard-item">
        <div>
          <div class="hazard-title">${inc.title}</div>
          <div class="hazard-sub">+${inc.delayMin} min delay | ${inc.type}</div>
        </div>
        <button class="btn-remove-hazard" onclick="window.app.removeIncident('${inc.id}')">Clear</button>
      </div>
    `).join('');
  }

  clearRoute() {
    this.currentRouteResult = null;
    this.map.clearRoutes();
    this.dom.emptyRoutesPlaceholder.classList.remove('hidden');
    this.dom.routeCardsList.classList.add('hidden');
    this.dom.selectedRouteDetails.classList.add('hidden');
  }

  connectWebSocket() {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${location.host}`;
    this.ws = new WebSocket(wsUrl);

    this.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        this.handleWebSocketMessage(msg);
      } catch (err) {
        console.error('WS Parse Error:', err);
      }
    };

    this.ws.onclose = () => {
      setTimeout(() => this.connectWebSocket(), 3000);
    };
  }

  handleWebSocketMessage(msg) {
    switch (msg.type) {
      case 'TRAFFIC_UPDATE':
        for (const item of msg.data.updatedEdges) {
          this.map.updateEdgeTraffic(item.edgeId, item.currentSpeedKmh, item.congestionFactor);
        }
        break;

      case 'INCIDENT_ADDED':
        this.showToast(`⚠️ Hazard Reported: ${msg.data.incident.title}`, 'warning');
        this.fetchNetworkIncidents();
        break;

      case 'INCIDENT_REMOVED':
        this.fetchNetworkIncidents();
        break;

      case 'TRIP_UPDATE':
        this.activeTripStatus = msg.data;
        this.map.updateVehiclePosition(msg.data.currentPosition, msg.data.headingDeg, msg.data.currentSpeedKmh);
        const allRoutes = this.getAllRoutesList();
        this.hud.update(msg.data, allRoutes[this.selectedRouteIndex]);
        break;

      case 'REROUTE_ALERT':
        this.hud.showReroutePrompt(msg.data);
        break;

      case 'SCENARIO_CHANGED':
        this.fetchTelemetry();
        break;
    }
  }

  async fetchNetworkIncidents() {
    const res = await fetch('/api/network');
    const data = await res.json();
    this.map.renderIncidents(data.incidents);
    this.renderActiveIncidentsList(data.incidents);
  }

  async fetchTelemetry() {
    try {
      const res = await fetch('/api/telemetry');
      const data = await res.json();
      this.telemetry.updateTelemetry(data);
    } catch (e) {
      // Ignore
    }
  }

  startTelemetryPoller() {
    setInterval(() => {
      this.fetchTelemetry();
    }, 4000);
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    let icon = 'fa-info-circle text-primary';
    if (type === 'success') icon = 'fa-check-circle text-emerald';
    if (type === 'warning') icon = 'fa-triangle-exclamation text-amber';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
    this.dom.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
}

// Instantiate and expose globally
window.addEventListener('DOMContentLoaded', () => {
  window.app = new App();
  window.app.init();
});
