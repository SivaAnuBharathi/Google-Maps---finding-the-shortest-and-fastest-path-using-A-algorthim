/**
 * liveMap.js - Leaflet Map Controller with OpenStreetMap (OSM) & Navigation Map Heads
 * Handles multi-basemap switching (OSM Standard, OSM HOT, Carto, Topo, Satellite),
 * directional rotating vehicle head, compass rose, and OSM tag inspector.
 */

class LiveMapManager {
  constructor() {
    this.map = null;
    this.currentBasemapKey = 'cartoDark';
    this.currentTileLayer = null;

    this.basemaps = {
      osmStandard: {
        name: 'OSM Standard',
        url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors'
      },
      osmHot: {
        name: 'OSM Humanitarian',
        url: 'https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
        maxZoom: 19,
        subdomains: 'abc',
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Tiles style by Humanitarian OpenStreetMap Team'
      },
      cartoDark: {
        name: 'Carto Dark Matter',
        url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        maxZoom: 19,
        subdomains: 'abcd',
        attribution: '&copy; <a href="https://carto.com/">CARTO</a> &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
      },
      cartoPositron: {
        name: 'Carto Light (Positron)',
        url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
        maxZoom: 19,
        subdomains: 'abcd',
        attribution: '&copy; <a href="https://carto.com/">CARTO</a> &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
      },
      openTopo: {
        name: 'OpenTopoMap (Terrain)',
        url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        maxZoom: 17,
        subdomains: 'abc',
        attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>, SRTM | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a>'
      },
      esriSatellite: {
        name: 'Satellite Imagery',
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        maxZoom: 18,
        attribution: 'Tiles &copy; Esri, Maxar, Earthstar Geographics'
      }
    };

    this.layers = {
      baseRoads: L.layerGroup(),
      trafficOverlay: L.layerGroup(),
      routes: L.layerGroup(),
      nodes: L.layerGroup(),
      tolls: L.layerGroup(),
      hazards: L.layerGroup(),
      vehicle: L.layerGroup()
    };

    this.edgePolylines = new Map(); // edgeId -> L.polyline
    this.nodeMarkers = new Map(); // nodeId -> L.marker
    this.hazardMarkers = new Map(); // incidentId -> L.marker
    this.vehicleMarker = null;

    // Heading and Navigation Heads state
    this.currentHeadingDeg = 0;
    this.isCourseUp = false; // Course-Up mode vs North-Up mode

    this.onNodeClickCallback = null;
    this.activeRouteLayers = [];
  }

  init(elementId = 'leaflet-map', onNodeClick = null) {
    this.onNodeClickCallback = onNodeClick;

    // Centered on Tamil Nadu
    this.map = L.map(elementId, {
      center: [11.1271, 78.6569],
      zoom: 7,
      minZoom: 6,
      maxZoom: 18,
      zoomControl: false
    });

    L.control.zoom({ position: 'bottomright' }).addTo(this.map);

    // Add initial basemap (Carto Dark by default)
    this.setBasemap('cartoDark');

    // Add layer groups to map
    for (const group of Object.values(this.layers)) {
      group.addTo(this.map);
    }

    return this;
  }

  /**
   * Switch basemap to any OpenStreetMap (OSM) or Satellite provider
   */
  setBasemap(providerKey) {
    if (!this.basemaps[providerKey]) return;

    if (this.currentTileLayer) {
      this.map.removeLayer(this.currentTileLayer);
    }

    const cfg = this.basemaps[providerKey];
    this.currentBasemapKey = providerKey;
    this.currentTileLayer = L.tileLayer(cfg.url, {
      maxZoom: cfg.maxZoom,
      subdomains: cfg.subdomains || 'abc',
      attribution: cfg.attribution
    }).addTo(this.map);

    // If switching to an OSM layer, update road polyline contrast
    const isLightOrTopo = providerKey === 'cartoPositron' || providerKey === 'osmStandard' || providerKey === 'osmHot' || providerKey === 'openTopo';
    this.updateLayerStylesForBasemap(isLightOrTopo);
  }

  updateLayerStylesForBasemap(isLight) {
    // Slight opacity tweak for road lines on light tiles
    this.edgePolylines.forEach(poly => {
      poly.setStyle({ opacity: isLight ? 0.85 : 0.75 });
    });
  }

  renderNetwork(nodes, edges) {
    this.layers.baseRoads.clearLayers();
    this.layers.nodes.clearLayers();
    this.layers.tolls.clearLayers();
    this.edgePolylines.clear();
    this.nodeMarkers.clear();

    // 1. Render all road network edges as base lines
    for (const edge of edges) {
      if (!edge.geometry || edge.geometry.length === 0) continue;

      const polyline = L.polyline(edge.geometry, {
        color: this.getCongestionColor(edge.congestionFactor),
        weight: edge.category === 'Expressway' ? 5 : (edge.category === 'National Highway' ? 4 : 3),
        opacity: 0.75,
        smoothFactor: 1
      });

      // Rich OSM Tag Inspector in popup
      const osmTags = edge.osmTags || {};
      const tagRows = Object.entries(osmTags).map(([k, v]) => `
        <div style="display:flex; justify-content:space-between; padding:2px 0; border-bottom:1px solid #f1f5f9;">
          <code style="color:#0284c7; font-weight:600;">${k}</code>
          <code style="color:#334155;">${v}</code>
        </div>
      `).join('');

      polyline.bindPopup(`
        <div class="osm-popup-card" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 12px; color: #0f172a; min-width: 250px;">
          <div style="background:#0f172a; color:#fff; padding:6px 10px; border-radius:6px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
            <b>${edge.name}</b>
            <span style="background:#10b981; color:#fff; font-size:10px; padding:2px 5px; border-radius:4px; font-weight:700;">${edge.highwayRef || 'OSM'}</span>
          </div>
          
          <div style="margin-bottom:8px;">
            <span>Category: <b>${edge.category}</b> (${edge.lanes} Lanes)</span><br/>
            <span>Distance: <b>${edge.distanceKm} km</b></span><br/>
            <span>Live Speed: <b>${edge.currentSpeedKmh} km/h</b> (Free Flow: ${edge.freeFlowSpeedKmh} km/h)</span><br/>
            <span>Congestion Factor: <b style="color: ${this.getCongestionColor(edge.congestionFactor)};">${(edge.congestionFactor).toFixed(2)}x</b></span>
          </div>

          <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; padding:6px 8px;">
            <div style="font-size:10px; font-weight:700; text-transform:uppercase; color:#64748b; margin-bottom:4px; display:flex; align-items:center; gap:4px;">
              <i class="fa-solid fa-code"></i> OpenStreetMap (OSM) Tags
            </div>
            ${tagRows}
          </div>
        </div>
      `);

      polyline.addTo(this.layers.baseRoads);
      this.edgePolylines.set(edge.id, polyline);

      // Render Toll Plazas if present
      if (edge.tolls && edge.tolls.length > 0) {
        const midPoint = edge.geometry[Math.floor(edge.geometry.length / 2)];
        for (const toll of edge.tolls) {
          const tollIcon = L.divIcon({
            className: 'marker-toll',
            html: '<i class="fa-solid fa-receipt"></i>',
            iconSize: [22, 22],
            iconAnchor: [11, 11]
          });
          const tollMarker = L.marker(midPoint, { icon: tollIcon });
          tollMarker.bindTooltip(`<b>${toll.name}</b><br/>FASTag Delay: ~${toll.delay} mins`, { direction: 'top' });
          tollMarker.addTo(this.layers.tolls);
        }
      }
    }

    // 2. Render all Nodes (Tamil Nadu Cities & Junctions)
    for (const node of nodes) {
      const isTier1 = node.tier === 1;
      const marker = L.circleMarker([node.lat, node.lng], {
        radius: isTier1 ? 6 : 4,
        fillColor: isTier1 ? '#3B82F6' : '#94A3B8',
        color: '#FFFFFF',
        weight: 1.5,
        opacity: 0.9,
        fillOpacity: 0.85
      });

      marker.bindTooltip(`<b>${node.name}</b><br/><span style="font-size: 10px; color: #64748B;">${node.district} District | OSM Node</span>`, {
        direction: 'top',
        offset: [0, -5]
      });

      marker.on('click', () => {
        if (this.onNodeClickCallback) {
          this.onNodeClickCallback(node);
        }
      });

      marker.addTo(this.layers.nodes);
      this.nodeMarkers.set(node.id, marker);
    }
  }

  updateEdgeTraffic(edgeId, currentSpeedKmh, congestionFactor) {
    const polyline = this.edgePolylines.get(edgeId);
    if (polyline) {
      const newColor = this.getCongestionColor(congestionFactor);
      polyline.setStyle({ color: newColor });
    }
  }

  getCongestionColor(factor) {
    if (factor <= 1.15) return '#10B981'; // Emerald
    if (factor <= 1.6) return '#F59E0B';  // Amber
    if (factor <= 2.3) return '#EF4444';  // Red
    return '#991B1B';                     // Dark Crimson
  }

  renderRoutes(routeResult, selectedRouteIndex = 0) {
    this.layers.routes.clearLayers();
    this.activeRouteLayers = [];

    const allRoutes = [];
    if (routeResult.primary) {
      allRoutes.push(routeResult.primary);
      if (routeResult.alternatives && routeResult.alternatives.length > 0) {
        allRoutes.push(...routeResult.alternatives);
      }
      if (routeResult.shortest && routeResult.shortest.edgeIds.join() !== routeResult.primary.edgeIds.join()) {
        allRoutes.push(routeResult.shortest);
      }
    } else {
      allRoutes.push(routeResult);
    }

    // Render alternatives first (behind primary)
    for (let i = allRoutes.length - 1; i >= 0; i--) {
      const r = allRoutes[i];
      const isSelected = i === selectedRouteIndex;

      let routeColor = isSelected ? '#10B981' : '#64748B';
      let weight = isSelected ? 7 : 4;
      let opacity = isSelected ? 0.95 : 0.45;
      let dashArray = null;

      if (r.routeTag === 'Shortest Distance') {
        routeColor = isSelected ? '#06B6D4' : '#0284C7';
        dashArray = '6, 6';
      } else if (r.routeTag === 'Alternative Corridor') {
        routeColor = isSelected ? '#8B5CF6' : '#6D28D9';
      }

      // Outline polyline
      const outline = L.polyline(r.geometry, {
        color: isSelected ? '#FFFFFF' : '#000000',
        weight: weight + 3,
        opacity: isSelected ? 0.35 : 0.2
      }).addTo(this.layers.routes);

      // Active colored polyline
      const line = L.polyline(r.geometry, {
        color: routeColor,
        weight: weight,
        opacity: opacity,
        dashArray: dashArray,
        lineCap: 'round',
        lineJoin: 'round'
      }).addTo(this.layers.routes);

      line.on('click', () => {
        window.app.selectRoute(i);
      });

      this.activeRouteLayers.push({ index: i, outline, line, route: r });
    }

    // Place Start & Destination animated markers
    const primary = allRoutes[selectedRouteIndex] || allRoutes[0];
    if (primary.origin && primary.destination) {
      this.setRouteEndpoints(primary.origin, primary.destination);
    }

    if (primary.bounds) {
      this.map.fitBounds(primary.bounds, { padding: [50, 50], maxZoom: 11 });
    }
  }

  setRouteEndpoints(origin, destination) {
    const originIcon = L.divIcon({
      className: 'custom-pulse-marker marker-origin',
      html: '<div class="pulse-ring"></div><div class="pulse-dot"></div>',
      iconSize: [14, 14],
      iconAnchor: [7, 7]
    });
    L.marker([origin.lat, origin.lng], { icon: originIcon })
      .bindTooltip(`<b>Start: ${origin.name}</b>`, { permanent: true, direction: 'top', offset: [0, -10] })
      .addTo(this.layers.routes);

    const destIcon = L.divIcon({
      className: 'custom-pulse-marker marker-dest',
      html: '<div class="pulse-ring"></div><div class="pulse-dot"></div>',
      iconSize: [14, 14],
      iconAnchor: [7, 7]
    });
    L.marker([destination.lat, destination.lng], { icon: destIcon })
      .bindTooltip(`<b>End: ${destination.name}</b>`, { permanent: true, direction: 'top', offset: [0, -10] })
      .addTo(this.layers.routes);
  }

  renderIncidents(incidents) {
    this.layers.hazards.clearLayers();
    this.hazardMarkers.clear();

    for (const inc of incidents) {
      if (!inc.lat || !inc.lng) continue;

      let iconClass = 'fa-solid fa-triangle-exclamation';
      if (inc.type === 'accident') iconClass = 'fa-solid fa-burst';
      else if (inc.type === 'toll_jam') iconClass = 'fa-solid fa-ban';
      else if (inc.type === 'waterlogging') iconClass = 'fa-solid fa-water';
      else if (inc.type === 'roadwork') iconClass = 'fa-solid fa-person-digging';

      const hazardIcon = L.divIcon({
        className: 'marker-hazard',
        html: `<i class="${iconClass}"></i>`,
        iconSize: [26, 26],
        iconAnchor: [13, 13]
      });

      const marker = L.marker([inc.lat, inc.lng], { icon: hazardIcon });
      marker.bindPopup(`
        <div style="font-family: sans-serif; font-size: 12px; color: #111;">
          <b style="color: #DC2626; font-size: 13px;">${inc.title}</b><br/>
          <span>${inc.description}</span><br/>
          <span>Delay Incurred: <b>+${inc.delayMin} min</b></span><br/>
          <span style="font-size: 10px; color: #64748B;">Reported: ${new Date(inc.timestamp).toLocaleTimeString()}</span>
        </div>
      `);

      marker.addTo(this.layers.hazards);
      this.hazardMarkers.set(inc.id, marker);
    }
  }

  /**
   * Update Vehicle Position with Mathematical Heading Angle (Map Heads)
   */
  updateVehiclePosition(latLng, headingDeg = 0, speedKmh = 60) {
    if (!latLng) return;

    this.currentHeadingDeg = headingDeg;

    // Directional rotating navigation vehicle arrow marker (Google Maps Head Arrow)
    const arrowHtml = `
      <div class="nav-vehicle-head" style="transform: rotate(${headingDeg}deg);">
        <div class="vehicle-cone"></div>
        <div class="vehicle-arrow-icon">
          <i class="fa-solid fa-location-arrow"></i>
        </div>
      </div>
    `;

    const vehicleIcon = L.divIcon({
      className: 'custom-vehicle-container',
      html: arrowHtml,
      iconSize: [36, 36],
      iconAnchor: [18, 18]
    });

    if (!this.vehicleMarker) {
      this.vehicleMarker = L.marker(latLng, { icon: vehicleIcon, zIndexOffset: 1500 }).addTo(this.layers.vehicle);
    } else {
      this.vehicleMarker.setLatLng(latLng);
      this.vehicleMarker.setIcon(vehicleIcon);
    }

    // Update map view smoothly
    if (this.isCourseUp) {
      this.map.panTo(latLng, { animate: true, duration: 0.8 });
    } else {
      if (this.map.getZoom() < 8) {
        this.map.panTo(latLng);
      }
    }
  }

  toggleCourseUp(forceState = null) {
    this.isCourseUp = forceState !== null ? forceState : !this.isCourseUp;
    return this.isCourseUp;
  }

  removeVehicle() {
    if (this.vehicleMarker) {
      this.layers.vehicle.removeLayer(this.vehicleMarker);
      this.vehicleMarker = null;
    }
  }

  toggleLayer(layerName, visible) {
    if (this.layers[layerName]) {
      if (visible) {
        this.layers[layerName].addTo(this.map);
      } else {
        this.map.removeLayer(this.layers[layerName]);
      }
    }
  }

  clearRoutes() {
    this.layers.routes.clearLayers();
    this.removeVehicle();
  }
}

window.LiveMapManager = LiveMapManager;
