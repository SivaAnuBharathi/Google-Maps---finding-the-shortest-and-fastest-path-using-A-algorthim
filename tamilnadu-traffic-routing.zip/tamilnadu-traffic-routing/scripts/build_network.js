const fs = require('fs');
const path = require('path');

// Comprehensive Tamil Nadu Road Network
const nodes = {
  // Chennai Metropolitan Region
  "chennai_central": { id: "chennai_central", name: "Chennai (Central)", district: "Chennai", lat: 13.0827, lng: 80.2707, tier: 1 },
  "chennai_koyambedu": { id: "chennai_koyambedu", name: "Chennai (Koyambedu CMBT)", district: "Chennai", lat: 13.0694, lng: 80.1948, tier: 1 },
  "chennai_guindy": { id: "chennai_guindy", name: "Chennai (Guindy Kathipara)", district: "Chennai", lat: 13.0067, lng: 80.2030, tier: 1 },
  "chennai_tambaram": { id: "chennai_tambaram", name: "Tambaram (South Chennai Gateway)", district: "Chengalpattu", lat: 12.9249, lng: 80.1000, tier: 1 },
  "chennai_omr": { id: "chennai_omr", name: "Chennai (OMR IT Corridor)", district: "Chennai", lat: 12.8996, lng: 80.2279, tier: 2 },
  "chennai_ennore": { id: "chennai_ennore", name: "Ennore Port (North Chennai)", district: "Tiruvallur", lat: 13.2000, lng: 80.3200, tier: 2 },
  "sriperumbudur": { id: "sriperumbudur", name: "Sriperumbudur (NH48 Hub)", district: "Kanchipuram", lat: 12.9675, lng: 79.9442, tier: 2 },
  
  // Northern & Western Industrial Belt (NH48)
  "kanchipuram": { id: "kanchipuram", name: "Kanchipuram", district: "Kanchipuram", lat: 12.8342, lng: 79.7036, tier: 2 },
  "arakkonam": { id: "arakkonam", name: "Arakkonam Junction", district: "Ranipet", lat: 13.0784, lng: 79.6677, tier: 2 },
  "ranipet": { id: "ranipet", name: "Ranipet / Walajah", district: "Ranipet", lat: 12.9272, lng: 79.3331, tier: 2 },
  "vellore": { id: "vellore", name: "Vellore Fort City", district: "Vellore", lat: 12.9165, lng: 79.1325, tier: 1 },
  "ambur": { id: "ambur", name: "Ambur", district: "Tirupattur", lat: 12.7904, lng: 78.7166, tier: 2 },
  "vaniyambadi": { id: "vaniyambadi", name: "Vaniyambadi", district: "Tirupattur", lat: 12.6825, lng: 78.6200, tier: 2 },
  "tirupattur": { id: "tirupattur", name: "Tirupattur", district: "Tirupattur", lat: 12.4950, lng: 78.5700, tier: 2 },
  "krishnagiri": { id: "krishnagiri", name: "Krishnagiri Junction (NH44/NH48)", district: "Krishnagiri", lat: 12.5186, lng: 78.2137, tier: 1 },
  "hosur": { id: "hosur", name: "Hosur (TN-KA Border Hub)", district: "Krishnagiri", lat: 12.7409, lng: 77.8253, tier: 1 },
  "dharmapuri": { id: "dharmapuri", name: "Dharmapuri", district: "Dharmapuri", lat: 12.1211, lng: 78.1582, tier: 2 },

  // GST Road Corridor (NH45 / NH38)
  "chengalpattu": { id: "chengalpattu", name: "Chengalpattu (Paranur Gateway)", district: "Chengalpattu", lat: 12.6819, lng: 79.9888, tier: 1 },
  "tindivanam": { id: "tindivanam", name: "Tindivanam (NH45/NH66 Hub)", district: "Villupuram", lat: 12.2286, lng: 79.6500, tier: 1 },
  "villupuram": { id: "villupuram", name: "Villupuram Junction", district: "Villupuram", lat: 11.9401, lng: 79.4861, tier: 1 },
  "ulundurpet": { id: "ulundurpet", name: "Ulundurpet (NH45/NH79 Hub)", district: "Kallakurichi", lat: 11.6917, lng: 79.2903, tier: 1 },
  "perambalur": { id: "perambalur", name: "Perambalur", district: "Perambalur", lat: 11.2342, lng: 78.8817, tier: 2 },
  "trichy": { id: "trichy", name: "Tiruchirappalli (Trichy)", district: "Tiruchirappalli", lat: 10.7905, lng: 78.7047, tier: 1 },

  // Coastal / ECR Corridor
  "marakkanam": { id: "marakkanam", name: "Marakkanam (ECR Scenic)", district: "Villupuram", lat: 12.1983, lng: 79.9536, tier: 2 },
  "puducherry": { id: "puducherry", name: "Puducherry (Pondicherry)", district: "Puducherry", lat: 11.9416, lng: 79.8083, tier: 1 },
  "cuddalore": { id: "cuddalore", name: "Cuddalore Port", district: "Cuddalore", lat: 11.7480, lng: 79.7714, tier: 2 },
  "chidambaram": { id: "chidambaram", name: "Chidambaram", district: "Cuddalore", lat: 11.3992, lng: 79.6936, tier: 2 },
  "mayiladuthurai": { id: "mayiladuthurai", name: "Mayiladuthurai", district: "Mayiladuthurai", lat: 11.1018, lng: 79.6522, tier: 2 },
  "nagapattinam": { id: "nagapattinam", name: "Nagapattinam Port", district: "Nagapattinam", lat: 10.7672, lng: 79.8449, tier: 2 },
  "ramanathapuram": { id: "ramanathapuram", name: "Ramanathapuram", district: "Ramanathapuram", lat: 9.3639, lng: 78.8395, tier: 2 },
  "rameswaram": { id: "rameswaram", name: "Rameswaram (Pamban Island)", district: "Ramanathapuram", lat: 9.2876, lng: 79.3129, tier: 2 },

  // Central Bypass & Hill Interior
  "tiruvannamalai": { id: "tiruvannamalai", name: "Tiruvannamalai", district: "Tiruvannamalai", lat: 12.2253, lng: 79.0747, tier: 2 },
  "harur": { id: "harur", name: "Harur", district: "Dharmapuri", lat: 12.0600, lng: 78.4900, tier: 2 },
  "attur": { id: "attur", name: "Attur (NH79 Corridor)", district: "Salem", lat: 11.5975, lng: 78.5997, tier: 2 },

  // Salem & Western Kongu Belt (NH44 / NH544)
  "salem": { id: "salem", name: "Salem Junction", district: "Salem", lat: 11.6643, lng: 78.1460, tier: 1 },
  "namakkal": { id: "namakkal", name: "Namakkal (Transport City)", district: "Namakkal", lat: 11.2189, lng: 78.1674, tier: 1 },
  "karur": { id: "karur", name: "Karur (Textile Hub)", district: "Karur", lat: 10.9601, lng: 78.0766, tier: 1 },
  "erode": { id: "erode", name: "Erode", district: "Erode", lat: 11.3410, lng: 77.7172, tier: 1 },
  "tiruppur": { id: "tiruppur", name: "Tiruppur (Knitwear Hub)", district: "Tiruppur", lat: 11.1085, lng: 77.3411, tier: 1 },
  "coimbatore": { id: "coimbatore", name: "Coimbatore", district: "Coimbatore", lat: 11.0168, lng: 76.9558, tier: 1 },
  "pollachi": { id: "pollachi", name: "Pollachi", district: "Coimbatore", lat: 10.6609, lng: 77.0048, tier: 2 },
  "mettupalayam": { id: "mettupalayam", name: "Mettupalayam (Ghat Base)", district: "Coimbatore", lat: 11.3000, lng: 76.9400, tier: 2 },
  "ooty": { id: "ooty", name: "Udhagamandalam (Ooty)", district: "Nilgiris", lat: 11.4102, lng: 76.6950, tier: 2 },

  // Cauvery Delta
  "thanjavur": { id: "thanjavur", name: "Thanjavur", district: "Thanjavur", lat: 10.7870, lng: 79.1378, tier: 1 },
  "kumbakonam": { id: "kumbakonam", name: "Kumbakonam", district: "Thanjavur", lat: 10.9602, lng: 79.3845, tier: 2 },
  "pudukkottai": { id: "pudukkottai", name: "Pudukkottai", district: "Pudukkottai", lat: 10.3797, lng: 78.8208, tier: 2 },

  // Southern Plains & NH44 South (Madurai - Kanyakumari)
  "dindigul": { id: "dindigul", name: "Dindigul (NH44 / Biryani Hub)", district: "Dindigul", lat: 10.3673, lng: 77.9803, tier: 1 },
  "palani": { id: "palani", name: "Palani", district: "Dindigul", lat: 10.4500, lng: 77.5200, tier: 2 },
  "theni": { id: "theni", name: "Theni (Western Foothills)", district: "Theni", lat: 10.0104, lng: 77.4768, tier: 2 },
  "madurai": { id: "madurai", name: "Madurai (Temple City Gateway)", district: "Madurai", lat: 9.9252, lng: 78.1198, tier: 1 },
  "virudhunagar": { id: "virudhunagar", name: "Virudhunagar (NH44)", district: "Virudhunagar", lat: 9.5872, lng: 77.9514, tier: 2 },
  "sivakasi": { id: "sivakasi", name: "Sivakasi", district: "Virudhunagar", lat: 9.4533, lng: 77.7978, tier: 2 },
  "rajapalayam": { id: "rajapalayam", name: "Rajapalayam", district: "Virudhunagar", lat: 9.4500, lng: 77.5500, tier: 2 },
  "kovilpatti": { id: "kovilpatti", name: "Kovilpatti", district: "Thoothukudi", lat: 9.1726, lng: 77.8687, tier: 2 },
  "tirunelveli": { id: "tirunelveli", name: "Tirunelveli (Halwa City)", district: "Tirunelveli", lat: 8.7139, lng: 77.7567, tier: 1 },
  "tenkasi": { id: "tenkasi", name: "Tenkasi (Courtallam)", district: "Tenkasi", lat: 8.9594, lng: 77.3150, tier: 2 },
  "thoothukudi": { id: "thoothukudi", name: "Thoothukudi (Tuticorin Port)", district: "Thoothukudi", lat: 8.7642, lng: 78.1348, tier: 1 },
  "nagercoil": { id: "nagercoil", name: "Nagercoil", district: "Kanyakumari", lat: 8.1833, lng: 77.4119, tier: 2 },
  "kanyakumari": { id: "kanyakumari", name: "Kanyakumari (Land's End)", district: "Kanyakumari", lat: 8.0883, lng: 77.5385, tier: 1 }
};

// Define roads connecting nodes with realistic highway data
const roadConnections = [
  // --- Chennai Urban Arterials ---
  { from: "chennai_central", to: "chennai_guindy", name: "Anna Salai (Mount Road)", category: "Arterial", lanes: 6, dist: 13, speed: 45 },
  { from: "chennai_central", to: "chennai_koyambedu", name: "Poonamallee High Road", category: "Arterial", lanes: 6, dist: 11, speed: 40 },
  { from: "chennai_central", to: "chennai_ennore", name: "Manali High Road", category: "Arterial", lanes: 4, dist: 18, speed: 40 },
  { from: "chennai_koyambedu", to: "chennai_guindy", name: "Inner Ring Road (Jawaharlal Nehru Salai)", category: "Arterial", lanes: 6, dist: 9, speed: 50 },
  { from: "chennai_guindy", to: "chennai_omr", name: "Sardar Patel Rd & OMR Link", category: "Arterial", lanes: 6, dist: 14, speed: 45 },
  { from: "chennai_guindy", to: "chennai_tambaram", name: "GST Road (Kathipara - Tambaram)", category: "Arterial", lanes: 6, dist: 16, speed: 50, tolls: [{ name: "Tambaram MEPZ Checkpoint", delay: 2 }] },
  { from: "chennai_omr", to: "chennai_tambaram", name: "Radial Road (Pallavaram-Thoraipakkam 200ft)", category: "Arterial", lanes: 6, dist: 15, speed: 55 },
  { from: "chennai_koyambedu", to: "sriperumbudur", name: "NH48 (Chennai Outer - Poonamallee Bypass)", category: "National Highway", lanes: 6, dist: 32, speed: 75, tolls: [{ name: "Nemili / Sriperumbudur Toll Plaza", delay: 4 }] },
  { from: "chennai_tambaram", to: "sriperumbudur", name: "Chennai Outer Ring Road (ORR)", category: "Expressway", lanes: 6, dist: 28, speed: 90 },

  // --- GST Highway Corridor (NH45 / NH38) ---
  { from: "chennai_tambaram", to: "chengalpattu", name: "NH45 (GST Road: Tambaram - Chengalpattu)", category: "National Highway", lanes: 6, dist: 30, speed: 85, tolls: [{ name: "Paranur Toll Plaza (Chengalpattu)", delay: 6 }] },
  { from: "chengalpattu", to: "tindivanam", name: "NH45 (Chengalpattu - Tindivanam Expressway)", category: "Expressway", lanes: 6, dist: 68, speed: 95, tolls: [{ name: "Athur Toll Plaza", delay: 5 }] },
  { from: "tindivanam", to: "villupuram", name: "NH45 (Tindivanam - Villupuram)", category: "National Highway", lanes: 4, dist: 38, speed: 90, tolls: [{ name: "Vikravandi Toll Plaza", delay: 5 }] },
  { from: "villupuram", to: "ulundurpet", name: "NH45 (Villupuram - Ulundurpet)", category: "National Highway", lanes: 4, dist: 40, speed: 90, tolls: [{ name: "Sengurichi Toll Plaza", delay: 4 }] },
  { from: "ulundurpet", to: "perambalur", name: "NH45 (Ulundurpet - Perambalur)", category: "National Highway", lanes: 4, dist: 60, speed: 95, tolls: [{ name: "Thirumandurai Toll Plaza", delay: 4 }] },
  { from: "perambalur", to: "trichy", name: "NH45 (Perambalur - Samayapuram - Trichy)", category: "National Highway", lanes: 4, dist: 56, speed: 90, tolls: [{ name: "Samayapuram Toll Plaza", delay: 6 }] },

  // --- NH48 Western Corridor (Chennai -> Vellore -> Krishnagiri) ---
  { from: "sriperumbudur", to: "kanchipuram", name: "NH48 (Sriperumbudur - Walajabad - Kanchipuram)", category: "National Highway", lanes: 6, dist: 36, speed: 85 },
  { from: "kanchipuram", to: "ranipet", name: "NH48 (Kanchipuram - Ranipet)", category: "National Highway", lanes: 6, dist: 44, speed: 90, tolls: [{ name: "Chennasamudram Toll Plaza", delay: 5 }] },
  { from: "ranipet", to: "arakkonam", name: "SH61 (Ranipet - Arakkonam Link)", category: "State Highway", lanes: 2, dist: 28, speed: 60 },
  { from: "ranipet", to: "vellore", name: "NH48 (Walajah - Katpadi - Vellore Bypass)", category: "National Highway", lanes: 6, dist: 25, speed: 85 },
  { from: "vellore", to: "ambur", name: "NH48 (Vellore - Pallikonda - Ambur)", category: "National Highway", lanes: 6, dist: 52, speed: 90, tolls: [{ name: "Pallikonda Toll Plaza", delay: 4 }] },
  { from: "ambur", to: "vaniyambadi", name: "NH48 (Ambur - Vaniyambadi)", category: "National Highway", lanes: 6, dist: 18, speed: 90 },
  { from: "vaniyambadi", to: "tirupattur", name: "SH18 (Vaniyambadi - Tirupattur)", category: "State Highway", lanes: 2, dist: 24, speed: 65 },
  { from: "vaniyambadi", to: "krishnagiri", name: "NH48 (Vaniyambadi - Bargur - Krishnagiri)", category: "National Highway", lanes: 6, dist: 50, speed: 90, tolls: [{ name: "Vaniyambadi Toll Plaza", delay: 4 }] },
  { from: "krishnagiri", to: "hosur", name: "NH44 (Krishnagiri - Hosur Expressway)", category: "Expressway", lanes: 6, dist: 52, speed: 95, tolls: [{ name: "Krishnagiri Toll Plaza", delay: 5 }] },

  // --- NH44 North-South Spine (Krishnagiri -> Dharmapuri -> Salem -> Namakkal -> Karur -> Dindigul) ---
  { from: "krishnagiri", to: "dharmapuri", name: "NH44 (Krishnagiri - Dharmapuri 4-Lane)", category: "Expressway", lanes: 4, dist: 46, speed: 90, tolls: [{ name: "Palacode Toll Plaza", delay: 4 }] },
  { from: "dharmapuri", to: "salem", name: "NH44 (Dharmapuri - Thoppur Ghat - Salem)", category: "National Highway", lanes: 4, dist: 65, speed: 80, tolls: [{ name: "Thoppur Toll Plaza", delay: 6 }] },
  { from: "salem", to: "namakkal", name: "NH44 (Salem - Rasipuram - Namakkal)", category: "Expressway", lanes: 4, dist: 54, speed: 95, tolls: [{ name: "Mettupatti Toll Plaza", delay: 4 }] },
  { from: "namakkal", to: "karur", name: "NH44 (Namakkal - Mohanur - Karur Bypass)", category: "National Highway", lanes: 4, dist: 44, speed: 90, tolls: [{ name: "Vangal Toll Plaza", delay: 4 }] },
  { from: "karur", to: "dindigul", name: "NH44 (Karur - Vedasandur - Dindigul)", category: "Expressway", lanes: 4, dist: 74, speed: 95, tolls: [{ name: "Velanchettiyur Toll Plaza", delay: 4 }] },

  // --- NH79 Ulundurpet to Salem Expressway (Key Central Shortcut) ---
  { from: "ulundurpet", to: "attur", name: "NH79 (Ulundurpet - Kallakurichi - Attur Expressway)", category: "Expressway", lanes: 4, dist: 80, speed: 95, tolls: [{ name: "Kallakurichi Toll Plaza", delay: 4 }] },
  { from: "attur", to: "salem", name: "NH79 (Attur - Vazhapadi - Salem Expressway)", category: "Expressway", lanes: 4, dist: 54, speed: 95, tolls: [{ name: "Vazhapadi Toll Plaza", delay: 4 }] },

  // --- Western Kongu Highway (NH544: Salem -> Erode -> Tiruppur -> Coimbatore) ---
  { from: "salem", to: "erode", name: "NH544 (Salem - Sankari - Erode Chithode Bypass)", category: "Expressway", lanes: 6, dist: 64, speed: 95, tolls: [{ name: "Sankari Toll Plaza", delay: 5 }] },
  { from: "erode", to: "tiruppur", name: "NH544 / SH17 (Perundurai - Vijayamangalam - Tiruppur)", category: "National Highway", lanes: 6, dist: 50, speed: 85, tolls: [{ name: "Vijayamangalam Toll Plaza", delay: 5 }] },
  { from: "tiruppur", to: "coimbatore", name: "NH544 (Tiruppur - Avinashi - Coimbatore Neelambur)", category: "Expressway", lanes: 6, dist: 52, speed: 90, tolls: [{ name: "Kaniyur Toll Plaza", delay: 5 }] },
  { from: "erode", to: "karur", name: "SH84 (Erode - Kodumudi - Karur Cauvery Bank)", category: "State Highway", lanes: 2, dist: 66, speed: 65 },
  { from: "tiruppur", to: "karur", name: "NH81 (Tiruppur - Kangeyam - Vellakoil - Karur)", category: "National Highway", lanes: 4, dist: 92, speed: 85 },
  { from: "coimbatore", to: "pollachi", name: "SH21 (Coimbatore - Kinathukadavu - Pollachi 4-Lane)", category: "State Highway", lanes: 4, dist: 42, speed: 75 },
  { from: "coimbatore", to: "mettupalayam", name: "NH181 (Coimbatore - Thudiyalur - Mettupalayam)", category: "National Highway", lanes: 4, dist: 35, speed: 70 },
  { from: "mettupalayam", to: "ooty", name: "NH181 (Mettupalayam - Coonoor - Ooty Ghat Road)", category: "Ghat Road", lanes: 2, dist: 52, speed: 38, tolls: [{ name: "Burliar Forest Toll", delay: 3 }] },

  // --- East Coast Corridor (ECR - NH32) & Delta Ports ---
  { from: "chennai_omr", to: "marakkanam", name: "ECR (Mahabalipuram - Kalpakkam - Marakkanam)", category: "State Highway", lanes: 2, dist: 88, speed: 70, tolls: [{ name: "Uthandi Toll Plaza", delay: 4 }] },
  { from: "marakkanam", to: "puducherry", name: "ECR (Marakkanam - Puducherry)", category: "State Highway", lanes: 4, dist: 35, speed: 75 },
  { from: "chengalpattu", to: "marakkanam", name: "SH58 (Chengalpattu - Cheyyur - ECR Link)", category: "State Highway", lanes: 2, dist: 48, speed: 65 },
  { from: "tindivanam", to: "puducherry", name: "NH332 (Tindivanam - Kiliyanur - Puducherry)", category: "National Highway", lanes: 4, dist: 40, speed: 80, tolls: [{ name: "Moratandi Toll Plaza", delay: 4 }] },
  { from: "villupuram", to: "puducherry", name: "NH332 (Villupuram - Valavanur - Puducherry)", category: "National Highway", lanes: 4, dist: 38, speed: 75 },
  { from: "puducherry", to: "cuddalore", name: "NH32 (Puducherry - Ariyankuppam - Cuddalore)", category: "National Highway", lanes: 4, dist: 24, speed: 65 },
  { from: "cuddalore", to: "chidambaram", name: "NH32 (Cuddalore - Alapakkam - Chidambaram)", category: "National Highway", lanes: 4, dist: 44, speed: 75 },
  { from: "chidambaram", to: "mayiladuthurai", name: "NH32 (Chidambaram - Sirkazhi - Mayiladuthurai)", category: "National Highway", lanes: 2, dist: 38, speed: 65 },
  { from: "mayiladuthurai", to: "nagapattinam", name: "NH32 (Mayiladuthurai - Karaikal - Nagapattinam)", category: "National Highway", lanes: 2, dist: 54, speed: 65 },
  { from: "nagapattinam", to: "thanjavur", name: "NH83 (Nagapattinam - Tiruvarur - Thanjavur)", category: "National Highway", lanes: 4, dist: 85, speed: 75 },
  { from: "nagapattinam", to: "ramanathapuram", name: "ECR South (Nagapattinam - Muthupet - Ramanathapuram)", category: "State Highway", lanes: 2, dist: 185, speed: 70 },
  { from: "ramanathapuram", to: "rameswaram", name: "NH87 (Ramanathapuram - Mandapam - Pamban Bridge - Rameswaram)", category: "National Highway", lanes: 2, dist: 56, speed: 70 },

  // --- Cauvery Delta & Central Cross-Links ---
  { from: "trichy", to: "thanjavur", name: "NH83 (Trichy - Tuvakudi - Thanjavur 4-Lane)", category: "Expressway", lanes: 4, dist: 56, speed: 90, tolls: [{ name: "Valavanthankottai Toll Plaza", delay: 4 }] },
  { from: "thanjavur", to: "kumbakonam", name: "NH36 (Thanjavur - Papanasam - Kumbakonam)", category: "National Highway", lanes: 2, dist: 40, speed: 60 },
  { from: "kumbakonam", to: "mayiladuthurai", name: "SH64 (Kumbakonam - Mayiladuthurai)", category: "State Highway", lanes: 2, dist: 35, speed: 60 },
  { from: "kumbakonam", to: "perambalur", name: "SH139 (Kumbakonam - Jayankondam - Perambalur)", category: "State Highway", lanes: 2, dist: 78, speed: 65 },
  { from: "trichy", to: "karur", name: "NH81 (Trichy - Kulithalai - Karur Cauvery Express)", category: "National Highway", lanes: 4, dist: 80, speed: 85 },
  { from: "trichy", to: "pudukkottai", name: "NH336 (Trichy - Keeranur - Pudukkottai)", category: "National Highway", lanes: 4, dist: 54, speed: 85, tolls: [{ name: "Lembalakudi Toll Plaza", delay: 4 }] },
  { from: "pudukkottai", to: "madurai", name: "NH38 (Pudukkottai - Tiruppattur - Melur - Madurai)", category: "National Highway", lanes: 4, dist: 110, speed: 85, tolls: [{ name: "Chittampatti Toll Plaza", delay: 4 }] },

  // --- Interior Bypasses (Kanchi, Tiruvannamalai, Harur) ---
  { from: "chengalpattu", to: "kanchipuram", name: "SH58 (Chengalpattu - Walajabad - Kanchipuram)", category: "State Highway", lanes: 2, dist: 35, speed: 65 },
  { from: "kanchipuram", to: "tindivanam", name: "SH116 (Kanchipuram - Vandavasi - Tindivanam)", category: "State Highway", lanes: 2, dist: 75, speed: 70 },
  { from: "kanchipuram", to: "tiruvannamalai", name: "SH5 (Kanchipuram - Cheyyar - Chetpet - Tiruvannamalai)", category: "State Highway", lanes: 2, dist: 112, speed: 65 },
  { from: "tindivanam", to: "tiruvannamalai", name: "NH77 (Tindivanam - Gingee - Tiruvannamalai)", category: "National Highway", lanes: 2, dist: 70, speed: 75 },
  { from: "villupuram", to: "tiruvannamalai", name: "NH77 (Villupuram - Tiruvannamalai)", category: "National Highway", lanes: 2, dist: 62, speed: 70 },
  { from: "tiruvannamalai", to: "harur", name: "SH6A (Tiruvannamalai - Thanipadi - Harur)", category: "State Highway", lanes: 2, dist: 68, speed: 65 },
  { from: "harur", to: "dharmapuri", name: "SH60 (Harur - Morappur - Dharmapuri)", category: "State Highway", lanes: 2, dist: 45, speed: 65 },
  { from: "harur", to: "salem", name: "SH18 (Harur - Ayothiyapattinam - Salem)", category: "State Highway", lanes: 2, dist: 66, speed: 70 },
  { from: "tirupattur", to: "harur", name: "SH18 (Tirupattur - Singarapettai - Harur)", category: "State Highway", lanes: 2, dist: 52, speed: 65 },

  // --- Southern Hub (Madurai, Dindigul, Palani, Theni) ---
  { from: "trichy", to: "dindigul", name: "NH83 (Trichy - Manapparai - Dindigul 4-Lane)", category: "Expressway", lanes: 4, dist: 98, speed: 90, tolls: [{ name: "Ponnambalapatti Toll Plaza", delay: 4 }] },
  { from: "dindigul", to: "madurai", name: "NH44 (Dindigul - Kodai Road - Madurai 4-Lane)", category: "Expressway", lanes: 4, dist: 62, speed: 95, tolls: [{ name: "Kodai Road Toll Plaza", delay: 5 }] },
  { from: "dindigul", to: "palani", name: "NH83 (Dindigul - Reddiarchatram - Palani)", category: "National Highway", lanes: 2, dist: 58, speed: 75 },
  { from: "palani", to: "pollachi", name: "NH83 (Palani - Udumalpet - Pollachi)", category: "National Highway", lanes: 2, dist: 65, speed: 75 },
  { from: "madurai", to: "theni", name: "NH85 (Madurai - Usilampatti - Andipatti - Theni)", category: "National Highway", lanes: 2, dist: 72, speed: 75 },
  { from: "madurai", to: "ramanathapuram", name: "NH87 (Madurai - Manamadurai - Paramakudi - Ramanathapuram)", category: "National Highway", lanes: 4, dist: 115, speed: 85 },

  // --- NH44 South (Madurai -> Tirunelveli -> Kanyakumari) ---
  { from: "madurai", to: "virudhunagar", name: "NH44 (Madurai - Tirumangalam - Virudhunagar)", category: "Expressway", lanes: 4, dist: 48, speed: 95, tolls: [{ name: "Kappalur Toll Plaza", delay: 5 }] },
  { from: "virudhunagar", to: "kovilpatti", name: "NH44 (Virudhunagar - Sattur - Kovilpatti)", category: "Expressway", lanes: 4, dist: 58, speed: 95, tolls: [{ name: "Etturvattavilai Toll Plaza", delay: 4 }] },
  { from: "kovilpatti", to: "tirunelveli", name: "NH44 (Kovilpatti - Kayathar - Gangaikondan - Tirunelveli)", category: "Expressway", lanes: 4, dist: 60, speed: 95, tolls: [{ name: "Kayathar Toll Plaza", delay: 5 }] },
  { from: "tirunelveli", to: "nagercoil", name: "NH44 (Tirunelveli - Panagudi - Kavalkinaru - Nagercoil)", category: "National Highway", lanes: 4, dist: 74, speed: 85, tolls: [{ name: "Nanguneri Toll Plaza", delay: 4 }] },
  { from: "nagercoil", to: "kanyakumari", name: "NH44 (Nagercoil - Kottaram - Kanyakumari)", category: "National Highway", lanes: 4, dist: 20, speed: 75 },

  // --- Southern Arterials (Sivakasi, Rajapalayam, Tenkasi, Thoothukudi) ---
  { from: "virudhunagar", to: "sivakasi", name: "SH42 (Virudhunagar - Sivakasi Link)", category: "State Highway", lanes: 2, dist: 26, speed: 65 },
  { from: "sivakasi", to: "rajapalayam", name: "SH41 (Sivakasi - Srivilliputhur - Rajapalayam)", category: "State Highway", lanes: 2, dist: 32, speed: 65 },
  { from: "rajapalayam", to: "tenkasi", name: "NH744 (Rajapalayam - Sankarankovil - Puliyangudi - Tenkasi)", category: "National Highway", lanes: 2, dist: 62, speed: 70 },
  { from: "tirunelveli", to: "tenkasi", name: "SH39 (Tirunelveli - Alangulam - Tenkasi)", category: "State Highway", lanes: 2, dist: 52, speed: 70 },
  { from: "tirunelveli", to: "thoothukudi", name: "NH138 (Tirunelveli - Vagaikulam - Thoothukudi 4-Lane)", category: "National Highway", lanes: 4, dist: 48, speed: 85 },
  { from: "kovilpatti", to: "thoothukudi", name: "SH73 (Kovilpatti - Ottapidaram - Thoothukudi)", category: "State Highway", lanes: 2, dist: 60, speed: 70 },
  { from: "thoothukudi", to: "ramanathapuram", name: "ECR South (Thoothukudi - Sayalgudi - Ramanathapuram)", category: "State Highway", lanes: 2, dist: 135, speed: 75 }
];

// Helper to calculate realistic curved polyline points between two lat/lng coordinates
function generateCurvedGeometry(lat1, lng1, lat2, lng2, curvatureFactor = 0.08) {
  const points = [];
  const steps = 7;
  const midLat = (lat1 + lat2) / 2;
  const midLng = (lng1 + lng2) / 2;

  // Orthogonal vector for realistic highway natural curvature
  const dLat = lat2 - lat1;
  const dLng = lng2 - lng1;
  const normalLat = -dLng * curvatureFactor;
  const normalLng = dLat * curvatureFactor;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    // Quadratic Bezier curve
    const bLat = (1 - t) * (1 - t) * lat1 + 2 * (1 - t) * t * (midLat + normalLat) + t * t * lat2;
    const bLng = (1 - t) * (1 - t) * lng1 + 2 * (1 - t) * t * (midLng + normalLng) + t * t * lng2;
    points.push([Number(bLat.toFixed(5)), Number(bLng.toFixed(5))]);
  }
  return points;
}

// Build edges with both directions and realistic baseline travel times
const edges = [];
let edgeIdCounter = 1;

roadConnections.forEach(conn => {
  const u = nodes[conn.from];
  const v = nodes[conn.to];
  if (!u || !v) {
    console.error(`Missing node: ${conn.from} or ${conn.to}`);
    return;
  }

  const baseTravelTimeMin = Number(((conn.dist / conn.speed) * 60).toFixed(1));
  const totalTollDelay = (conn.tolls || []).reduce((sum, t) => sum + (t.delay || 0), 0);
  const geomForward = generateCurvedGeometry(u.lat, u.lng, v.lat, v.lng);
  const geomBackward = [...geomForward].reverse();

  // Extract Highway Ref from road name (e.g. NH45, NH44, SH58)
  const refMatch = conn.name.match(/(NH\s*\d+|SH\s*\d+)/i);
  const highwayRef = refMatch ? refMatch[0].toUpperCase().replace(/([A-Z]+)(\d+)/, '$1 $2') : 'TN-Road';
  
  const osmHighwayType = conn.category === 'Expressway' ? 'motorway' :
                         (conn.category === 'National Highway' ? 'trunk' :
                         (conn.category === 'State Highway' ? 'primary' :
                         (conn.category === 'Ghat Road' ? 'secondary' : 'tertiary')));

  const osmTags = {
    highway: osmHighwayType,
    ref: highwayRef,
    name: conn.name,
    lanes: String(conn.lanes),
    maxspeed: `${conn.speed} km/h`,
    surface: "asphalt",
    toll: (conn.tolls && conn.tolls.length > 0) ? "yes" : "no",
    operator: (conn.category === 'Expressway' || conn.category === 'National Highway') ? "National Highways Authority of India (NHAI)" : "Tamil Nadu Highways Department",
    state: "Tamil Nadu",
    country: "IN"
  };

  // Forward edge
  const id1 = `edge_${conn.from}_to_${conn.to}`;
  edges.push({
    id: id1,
    from: conn.from,
    to: conn.to,
    fromName: u.name,
    toName: v.name,
    name: conn.name,
    category: conn.category,
    lanes: conn.lanes,
    highwayRef: highwayRef,
    distanceKm: conn.dist,
    freeFlowSpeedKmh: conn.speed,
    currentSpeedKmh: conn.speed,
    baseTravelTimeMin: baseTravelTimeMin,
    currentTravelTimeMin: baseTravelTimeMin + totalTollDelay,
    congestionFactor: 1.0, // 1.0 = clear, 1.5 = moderate, 2.5 = heavy, 4.0 = standstill
    tolls: conn.tolls || [],
    tollDelayMin: totalTollDelay,
    incidentDelayMin: 0,
    incidents: [],
    geometry: geomForward,
    osmTags: osmTags
  });

  // Backward edge (since roads are bidirectional)
  const id2 = `edge_${conn.to}_to_${conn.from}`;
  edges.push({
    id: id2,
    from: conn.to,
    to: conn.from,
    fromName: v.name,
    toName: u.name,
    name: conn.name,
    category: conn.category,
    lanes: conn.lanes,
    highwayRef: highwayRef,
    distanceKm: conn.dist,
    freeFlowSpeedKmh: conn.speed,
    currentSpeedKmh: conn.speed,
    baseTravelTimeMin: baseTravelTimeMin,
    currentTravelTimeMin: baseTravelTimeMin + totalTollDelay,
    congestionFactor: 1.0,
    tolls: conn.tolls || [],
    tollDelayMin: totalTollDelay,
    incidentDelayMin: 0,
    incidents: [],
    geometry: geomBackward,
    osmTags: osmTags
  });
});

const network = {
  meta: {
    region: "Tamil Nadu, India",
    version: "2.5.0",
    totalNodes: Object.keys(nodes).length,
    totalEdges: edges.length,
    maxHighwaySpeed: 100, // km/h (used as upper bound for admissible A* heuristic)
    updatedAt: new Date().toISOString()
  },
  nodes,
  edges
};

const outputPath = path.join(__dirname, '..', 'data', 'tn_network.json');
fs.writeFileSync(outputPath, JSON.stringify(network, null, 2));
console.log(`Successfully generated Tamil Nadu network: ${Object.keys(nodes).length} nodes, ${edges.length} edges!`);
