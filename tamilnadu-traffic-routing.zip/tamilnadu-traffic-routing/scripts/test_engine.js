const { RoadGraph } = require('../src/graph');
const { aStarFastestPath, dijkstraShortestPath, findMultiRouteAlternatives } = require('../src/algorithms');
const { RouteCacheManager } = require('../src/cacheManager');
const networkData = require('../data/tn_network.json');

console.log("=== Testing Tamil Nadu Routing Engine ===");

const graph = new RoadGraph(networkData);
console.log(`Initialized graph with ${graph.nodes.size} nodes and ${graph.edges.size} edges.`);

// Test 1: Chennai to Madurai Dijkstra (Shortest distance)
console.log("\n[Test 1] Dijkstra Shortest Distance (Chennai Central -> Madurai)...");
const shortest = dijkstraShortestPath(graph, "chennai_central", "madurai");
console.log(`Shortest Path: ${shortest.totalDistanceKm} km, Travel Time: ${shortest.formattedETA}, Runtime: ${shortest.telemetry.runtimeMs} ms`);
console.log(`Route Path: ${shortest.pathNodeNames.join(" -> ")}`);

// Test 2: Chennai to Madurai Dynamic A* (Fastest route)
console.log("\n[Test 2] Dynamic A* Fastest Route (Chennai Central -> Madurai)...");
const fastest = aStarFastestPath(graph, "chennai_central", "madurai");
console.log(`Fastest Path: ${fastest.totalDistanceKm} km, Travel Time: ${fastest.formattedETA}, Runtime: ${fastest.telemetry.runtimeMs} ms`);
console.log(`Route Path: ${fastest.pathNodeNames.join(" -> ")}`);

// Test 3: Multi-route alternatives
console.log("\n[Test 3] Finding Alternative Corridors...");
const multi = findMultiRouteAlternatives(graph, "chennai_central", "madurai");
console.log(`Primary Route (${multi.primary.routeTag}): ${multi.primary.formattedETA}`);
if (multi.alternatives.length > 0) {
  multi.alternatives.forEach((alt, idx) => {
    console.log(`Alt ${idx + 1} (${alt.routeTag}): ${alt.formattedETA} (${alt.totalDistanceKm} km)`);
  });
}

// Test 4: Cache hit & Surgical Invalidation
console.log("\n[Test 4] Testing Cache and Surgical Invalidation...");
const cache = new RouteCacheManager();
cache.set("chennai_central", "madurai", "fastest", fastest, 5.0);

const cachedHit = cache.get("chennai_central", "madurai", "fastest");
console.log(`Cache Hit check: ${cachedHit ? "SUCCESS (Retrieved from cache)" : "FAIL"}`);

// Check telemetry
console.log("Cache Telemetry:", cache.getTelemetry());

// Invalidate Paranur Toll edge
console.log("\nSimulating 30% traffic delay spike at Paranur Toll (edge_chennai_tambaram_to_chengalpattu)...");
const evictedCount = cache.onEdgeTrafficChanged("edge_chennai_tambaram_to_chengalpattu", 0.30, 50, "Heavy queue");
console.log(`Evicted routes count: ${evictedCount}`);

const afterEviction = cache.get("chennai_central", "madurai", "fastest");
console.log(`Post-invalidation retrieval (should be null): ${afterEviction === null ? "SUCCESS (Correctly evicted!)" : "FAIL"}`);

console.log("\n=== All Core Engine Tests Passed! ===");
