/**
 * TripSimulator: Mid-Journey Vehicle Tracking & Dynamic Rerouting Engine
 * 
 * Simulates a vehicle driving along Tamil Nadu highway networks.
 * Evaluates real-time downstream conditions, calculates remaining travel time,
 * and triggers proactive detour recommendations when traffic bottlenecks form ahead.
 */

const { aStarFastestPath, formatMinutes } = require('./algorithms');
const { haversineDistance } = require('./graph');

function calculateBearing(lat1, lon1, lat2, lon2) {
  const toRad = deg => (deg * Math.PI) / 180.0;
  const toDeg = rad => (rad * 180.0) / Math.PI;

  const dLon = toRad(lon2 - lon1);
  const y = Math.sin(dLon) * Math.cos(toRad(lat2));
  const x = Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
            Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(dLon);
  const brng = toDeg(Math.atan2(y, x));
  return Math.round((brng + 360) % 360);
}

function getCompassDirection(deg) {
  const dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  const idx = Math.round(deg / 22.5) % 16;
  return dirs[idx];
}

class TripSimulator {
  constructor(graph, options = {}) {
    this.graph = graph;
    this.activeTrip = null;
    this.timer = null;
    this.rerouteThresholdMin = options.rerouteThresholdMin || 7.0; // Minimum time saving to suggest reroute
    this.simulationSpeed = 10; // 10x real-time speed by default
    this.onUpdateCallback = null;
    this.onRerouteAlertCallback = null;
  }

  startTrip(routeData, callbacks = {}) {
    this.stopTrip();

    this.onUpdateCallback = callbacks.onUpdate || null;
    this.onRerouteAlertCallback = callbacks.onRerouteAlert || null;

    if (!routeData || !routeData.geometry || routeData.geometry.length === 0) {
      throw new Error("Invalid route data for simulation");
    }

    this.activeTrip = {
      tripId: `trip_${Date.now()}`,
      route: routeData,
      destinationNodeId: routeData.destination.id,
      currentSegmentIndex: 0,
      currentWaypointIndex: 0,
      totalWaypoints: routeData.geometry.length,
      currentPosition: routeData.geometry[0], // [lat, lng]
      distanceTraveledKm: 0,
      totalDistanceKm: routeData.totalDistanceKm,
      remainingDistanceKm: routeData.totalDistanceKm,
      remainingTimeMin: routeData.totalTravelTimeMin,
      currentSpeedKmh: routeData.segmentBreakdown[0] ? routeData.segmentBreakdown[0].currentSpeedKmh : 75,
      isFinished: false,
      rerouteHistory: []
    };

    this.timer = setInterval(() => {
      this.step();
    }, 1000);

    return this.getStatus();
  }

  stopTrip() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.activeTrip = null;
  }

  setSimulationSpeed(multiplier) {
    this.simulationSpeed = Math.max(1, Math.min(50, Number(multiplier)));
  }

  step() {
    if (!this.activeTrip || this.activeTrip.isFinished) return;

    const trip = this.activeTrip;
    const geom = trip.route.geometry;

    // Advance waypoints based on simulated speed
    // e.g. at 60 km/h and 10x simulation speed = 600 km/h effective = ~0.16 km/sec
    const speed = trip.currentSpeedKmh || 60;
    const kmPerSecond = (speed / 3600) * this.simulationSpeed;

    // Advance waypoint index
    if (trip.currentWaypointIndex < geom.length - 1) {
      const prevCoord = geom[trip.currentWaypointIndex];
      trip.currentWaypointIndex++;
      const nextCoord = geom[trip.currentWaypointIndex];
      trip.currentPosition = nextCoord;

      // Calculate real-time mathematical heading (bearing angle in degrees: 0° - 360°)
      const headingDeg = calculateBearing(prevCoord[0], prevCoord[1], nextCoord[0], nextCoord[1]);
      trip.headingDeg = headingDeg;
      trip.compassDirection = getCompassDirection(headingDeg);

      // Update remaining distance and time
      const fraction = trip.currentWaypointIndex / (geom.length - 1);
      trip.distanceTraveledKm = Number((fraction * trip.totalDistanceKm).toFixed(1));
      trip.remainingDistanceKm = Number((trip.totalDistanceKm - trip.distanceTraveledKm).toFixed(1));

      // Determine current segment & road
      const segmentIndex = Math.min(
        trip.route.segmentBreakdown.length - 1,
        Math.floor(fraction * trip.route.segmentBreakdown.length)
      );
      trip.currentSegmentIndex = segmentIndex;
      const currentSegment = trip.route.segmentBreakdown[segmentIndex];
      if (currentSegment) {
        trip.currentSpeedKmh = currentSegment.currentSpeedKmh;
        
        // Generate Highway Signboard Head details (Maps Head)
        const highwayRef = currentSegment.highwayRef || (currentSegment.name.match(/(NH\s*\d+|SH\s*\d+)/i) ? currentSegment.name.match(/(NH\s*\d+|SH\s*\d+)/i)[0].toUpperCase() : 'TN HIGHWAY');
        const lanesCount = currentSegment.lanes || 4;
        
        // Lane guidance: indicate through lanes vs upcoming turn lanes
        const laneGuidance = [];
        for (let l = 0; l < lanesCount; l++) {
          if (l === lanesCount - 1 && segmentIndex < trip.route.segmentBreakdown.length - 1) {
            laneGuidance.push({ lane: l + 1, type: "exit", active: false });
          } else {
            laneGuidance.push({ lane: l + 1, type: "thru", active: true });
          }
        }

        const nextSeg = trip.route.segmentBreakdown[segmentIndex + 1];
        const nextExitName = nextSeg ? `Exit toward ${nextSeg.toName} (${nextSeg.name})` : `Arriving at ${trip.route.destination.name}`;
        const distToNextJunction = Number((currentSegment.distanceKm * (1 - (fraction % (1 / Math.max(1, trip.route.segmentBreakdown.length))))).toFixed(1));

        trip.mapHeadSignboard = {
          highwayRef,
          roadName: currentSegment.name,
          destinationTowns: [currentSegment.toName, trip.route.destination.name].filter(Boolean),
          nextExitName,
          distToNextJunctionKm: Math.max(0.5, distToNextJunction),
          lanesCount,
          laneGuidance,
          speedLimitKmh: currentSegment.freeFlowSpeedKmh,
          osmHighwayType: currentSegment.osmTags ? currentSegment.osmTags.highway : (currentSegment.category === 'Expressway' ? 'motorway' : 'trunk')
        };
      }

      // Proactive Mid-Journey Rerouting Check
      this.evaluateMidJourneyReroute();

      if (this.onUpdateCallback) {
        this.onUpdateCallback(this.getStatus());
      }
    } else {
      // Reached destination!
      trip.isFinished = true;
      trip.remainingDistanceKm = 0;
      trip.remainingTimeMin = 0;
      clearInterval(this.timer);
      this.timer = null;

      if (this.onUpdateCallback) {
        this.onUpdateCallback({ ...this.getStatus(), arrived: true });
      }
    }
  }

  /**
   * Mid-Journey Recalculation Engine:
   * Evaluates if conditions downstream have deteriorated.
   * If an alternative route from the upcoming junction saves > threshold minutes,
   * offers a seamless proactive reroute!
   */
  evaluateMidJourneyReroute() {
    const trip = this.activeTrip;
    if (!trip || trip.isFinished) return;

    // Only evaluate every ~4 seconds or when waypoints advance to an upcoming junction
    const currentPos = trip.currentPosition;
    const destId = trip.destinationNodeId;

    // Find the next upcoming graph junction along our remaining route
    const remainingSegments = trip.route.segmentBreakdown.slice(trip.currentSegmentIndex);
    if (remainingSegments.length <= 1) return; // Almost at destination

    const nextJunctionId = remainingSegments[0].to;
    if (!nextJunctionId || nextJunctionId === destId) return;

    // 1. Calculate travel time on CURRENT path for remaining segments
    let currentRemainingTime = 0;
    for (const seg of remainingSegments) {
      const liveEdge = this.graph.getEdge(seg.edgeId);
      currentRemainingTime += liveEdge ? liveEdge.currentTravelTimeMin : seg.travelTimeMin;
    }
    trip.remainingTimeMin = Number(currentRemainingTime.toFixed(1));

    // 2. Compute dynamic A* fastest route from next junction to destination
    const alternativeFromNextJunction = aStarFastestPath(this.graph, nextJunctionId, destId);

    if (!alternativeFromNextJunction.found) return;

    const altRemainingTime = alternativeFromNextJunction.totalTravelTimeMin;
    const timeSavedMin = Number((currentRemainingTime - altRemainingTime).toFixed(1));

    // 3. Compare with Reroute Threshold (Friction vs Time Savings)
    if (timeSavedMin >= this.rerouteThresholdMin) {
      // Check if alternative is genuinely different from current path
      const currentNextEdges = remainingSegments.map(s => s.edgeId).join();
      const altEdges = alternativeFromNextJunction.edgeIds.join();

      if (currentNextEdges !== altEdges) {
        const rerouteAlert = {
          tripId: trip.tripId,
          timestamp: new Date().toISOString(),
          timeSavedMin,
          formattedTimeSaved: `${Math.round(timeSavedMin)} min faster`,
          currentRemainingEta: formatMinutes(currentRemainingTime),
          newRemainingEta: formatMinutes(altRemainingTime),
          junctionNode: this.graph.getNode(nextJunctionId),
          reason: `Congestion detected on downstream route. Reroute via ${alternativeFromNextJunction.pathNodeNames.slice(1, 3).join(" → ")}`,
          newRoute: alternativeFromNextJunction
        };

        if (this.onRerouteAlertCallback) {
          this.onRerouteAlertCallback(rerouteAlert);
        }
      }
    }
  }

  /**
   * Apply recommended reroute mid-journey!
   */
  applyReroute(newRouteFromJunction) {
    if (!this.activeTrip) return false;

    const trip = this.activeTrip;
    // Combine traversed geometry up to current point with new remaining geometry
    const traversedGeometry = trip.route.geometry.slice(0, trip.currentWaypointIndex + 1);
    const combinedGeometry = [...traversedGeometry, ...newRouteFromJunction.geometry];

    trip.route = {
      ...trip.route,
      pathNodeIds: [...trip.route.pathNodeIds.slice(0, trip.currentSegmentIndex + 1), ...newRouteFromJunction.pathNodeIds],
      edgeIds: [...trip.route.edgeIds.slice(0, trip.currentSegmentIndex), ...newRouteFromJunction.edgeIds],
      geometry: combinedGeometry,
      segmentBreakdown: [...trip.route.segmentBreakdown.slice(0, trip.currentSegmentIndex), ...newRouteFromJunction.segmentBreakdown],
      totalDistanceKm: Number((trip.distanceTraveledKm + newRouteFromJunction.totalDistanceKm).toFixed(1)),
      totalTravelTimeMin: Number((trip.distanceTraveledKm / trip.currentSpeedKmh * 60 + newRouteFromJunction.totalTravelTimeMin).toFixed(1))
    };

    trip.rerouteHistory.push({
      timestamp: new Date().toLocaleTimeString(),
      via: newRouteFromJunction.pathNodeNames.slice(1, 3).join(" → "),
      savedMin: newRouteFromJunction.timeSavedMin || 10
    });

    return true;
  }

  getStatus() {
    if (!this.activeTrip) return { isActive: false };
    const trip = this.activeTrip;

    return {
      isActive: true,
      tripId: trip.tripId,
      currentPosition: trip.currentPosition,
      currentSpeedKmh: trip.currentSpeedKmh,
      headingDeg: trip.headingDeg !== undefined ? trip.headingDeg : 180,
      compassDirection: trip.compassDirection || "S",
      mapHeadSignboard: trip.mapHeadSignboard || null,
      distanceTraveledKm: trip.distanceTraveledKm,
      remainingDistanceKm: trip.remainingDistanceKm,
      remainingTimeMin: trip.remainingTimeMin,
      formattedRemainingETA: formatMinutes(trip.remainingTimeMin),
      progressPercent: Number(((trip.distanceTraveledKm / Math.max(1, trip.totalDistanceKm)) * 100).toFixed(1)),
      isFinished: trip.isFinished,
      simulationSpeed: `${this.simulationSpeed}x`,
      rerouteHistory: trip.rerouteHistory
    };
  }
}

module.exports = { TripSimulator };
