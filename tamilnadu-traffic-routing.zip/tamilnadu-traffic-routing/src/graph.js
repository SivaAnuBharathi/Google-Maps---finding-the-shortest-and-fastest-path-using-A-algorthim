/**
 * RoadGraph: Represents the road network of Tamil Nadu with nodes, edges,
 * adjacency lists, spatial metrics, and dynamic traffic attributes.
 */

// Earth radius in kilometers for Haversine calculations
const EARTH_RADIUS_KM = 6371.0;

function haversineDistance(lat1, lon1, lat2, lon2) {
  const toRad = deg => (deg * Math.PI) / 180.0;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_KM * c;
}

class RoadGraph {
  constructor(networkData) {
    this.meta = networkData.meta || {};
    this.nodes = new Map(); // id -> Node
    this.edges = new Map(); // id -> Edge
    this.adjacency = new Map(); // nodeId -> Array of outgoing Edge objects
    this.spatialIndex = []; // Fast spatial lookup list

    this.init(networkData);
  }

  init(data) {
    // Populate nodes
    for (const [id, node] of Object.entries(data.nodes)) {
      this.nodes.set(id, { ...node });
      this.adjacency.set(id, []);
      this.spatialIndex.push(node);
    }

    // Populate edges
    for (const edge of data.edges) {
      this.edges.set(edge.id, { ...edge });
      if (this.adjacency.has(edge.from)) {
        this.adjacency.get(edge.from).push(this.edges.get(edge.id));
      }
    }
  }

  getNode(nodeId) {
    return this.nodes.get(nodeId);
  }

  getAllNodes() {
    return Array.from(this.nodes.values());
  }

  getEdge(edgeId) {
    return this.edges.get(edgeId);
  }

  getAllEdges() {
    return Array.from(this.edges.values());
  }

  getOutgoingEdges(nodeId) {
    return this.adjacency.get(nodeId) || [];
  }

  /**
   * Find the nearest node in Tamil Nadu given latitude and longitude.
   */
  findNearestNode(lat, lng) {
    let nearest = null;
    let minDist = Infinity;
    for (const node of this.spatialIndex) {
      const dist = haversineDistance(lat, lng, node.lat, node.lng);
      if (dist < minDist) {
        minDist = dist;
        nearest = node;
      }
    }
    return { node: nearest, distanceKm: Number(minDist.toFixed(2)) };
  }

  /**
   * Dynamic Edge Re-weighting:
   * Recalculates edge travel time based on:
   * TravelTime = (Distance / CurrentSpeed) * 60 + TollDelay + IncidentDelay
   */
  updateEdgeDynamicWeight(edgeId, updates = {}) {
    const edge = this.edges.get(edgeId);
    if (!edge) return null;

    const previousTravelTime = edge.currentTravelTimeMin;

    if (updates.congestionFactor !== undefined) {
      edge.congestionFactor = Math.max(0.8, Number(updates.congestionFactor));
      // Effective speed = FreeFlowSpeed / CongestionFactor (minimum 10 km/h)
      edge.currentSpeedKmh = Math.max(10, Number((edge.freeFlowSpeedKmh / edge.congestionFactor).toFixed(1)));
    }

    if (updates.currentSpeedKmh !== undefined) {
      edge.currentSpeedKmh = Math.max(10, Math.min(edge.freeFlowSpeedKmh * 1.1, Number(updates.currentSpeedKmh)));
      edge.congestionFactor = Number((edge.freeFlowSpeedKmh / edge.currentSpeedKmh).toFixed(2));
    }

    if (updates.incidentDelayMin !== undefined) {
      edge.incidentDelayMin = Math.max(0, Number(updates.incidentDelayMin));
    }

    if (updates.incidents !== undefined) {
      edge.incidents = updates.incidents;
      edge.incidentDelayMin = updates.incidents.reduce((sum, inc) => sum + (inc.delayMin || 0), 0);
    }

    if (updates.tollDelayMin !== undefined) {
      edge.tollDelayMin = Math.max(0, Number(updates.tollDelayMin));
    }

    // Dynamic travel time in minutes
    const runningTimeMin = (edge.distanceKm / edge.currentSpeedKmh) * 60;
    edge.currentTravelTimeMin = Number((runningTimeMin + edge.tollDelayMin + edge.incidentDelayMin).toFixed(1));

    const deltaPercent = previousTravelTime > 0
      ? Math.abs(edge.currentTravelTimeMin - previousTravelTime) / previousTravelTime
      : 0;

    return {
      edge,
      previousTravelTime,
      currentTravelTimeMin: edge.currentTravelTimeMin,
      deltaPercent
    };
  }

  /**
   * Returns congestion status string & color for visualization.
   */
  static getCongestionStatus(congestionFactor) {
    if (congestionFactor <= 1.15) {
      return { status: "Free Flow", color: "#10B981", code: "green" }; // Emerald
    } else if (congestionFactor <= 1.6) {
      return { status: "Moderate", color: "#F59E0B", code: "orange" }; // Amber
    } else if (congestionFactor <= 2.3) {
      return { status: "Heavy Traffic", color: "#EF4444", code: "red" }; // Red
    } else {
      return { status: "Severe Gridlock", color: "#991B1B", code: "darkred" }; // Deep Maroon
    }
  }

  /**
   * Clone graph with modified edge penalties (used for Yen's K-Shortest Path)
   */
  cloneWithEdgePenalty(penaltyEdgeIds = new Set(), penaltyMultiplier = 3.0) {
    const cloned = new RoadGraph({ meta: this.meta, nodes: Object.fromEntries(this.nodes), edges: [] });
    for (const [id, edge] of this.edges) {
      const clonedEdge = { ...edge };
      if (penaltyEdgeIds.has(id)) {
        clonedEdge.currentTravelTimeMin *= penaltyMultiplier;
      }
      cloned.edges.set(id, clonedEdge);
      if (cloned.adjacency.has(clonedEdge.from)) {
        cloned.adjacency.get(clonedEdge.from).push(clonedEdge);
      }
    }
    return cloned;
  }
}

module.exports = { RoadGraph, haversineDistance, EARTH_RADIUS_KM };
