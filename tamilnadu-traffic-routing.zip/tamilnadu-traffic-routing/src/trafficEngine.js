/**
 * Real-Time Traffic Engine & Streaming Telemetry
 * - Simulates streaming connected vehicle speed probes
 * - Exponential Moving Average (EMA) speed dampening (prevents route fluttering)
 * - Incident management (accidents, monsoon waterlogging, toll bottlenecks)
 * - Preset traffic scenarios (Peak Rush, Festival Exodus, Monsoon)
 * - Event bus for notifying UI and Cache Invalidator
 */

const EventEmitter = require('events');

class TrafficEngine extends EventEmitter {
  constructor(graph, options = {}) {
    super();
    this.graph = graph;
    this.updateIntervalMs = options.updateIntervalMs || 4000;
    this.activeScenario = "normal";
    this.incidents = new Map(); // incidentId -> Incident
    this.incidentCounter = 1;
    this.timer = null;
    this.probesProcessed = 0;
    this.probeRatePerSec = 1420; // Simulated probe stream rate
    this.dampeningAlpha = 0.25; // EMA smoothing factor (0.0 to 1.0)

    // Preload sample initial incidents
    this.seedRealisticIncidents();
  }

  seedRealisticIncidents() {
    this.addIncident({
      edgeId: "edge_chennai_tambaram_to_chengalpattu",
      type: "toll_jam",
      title: "Paranur Toll Plaza Queue",
      description: "Severe FASTag lane queue backup extending 1.8km on GST Road.",
      delayMin: 18,
      lat: 12.7210,
      lng: 79.9920
    });

    this.addIncident({
      edgeId: "edge_chennai_guindy_to_chennai_tambaram",
      type: "accident",
      title: "Overturned Multi-Axle Lorry",
      description: "Lorry overturned near Chromepet Flyover blocking 2 outer lanes.",
      delayMin: 22,
      lat: 12.9520,
      lng: 80.1410
    });
  }

  startSimulation() {
    if (this.timer) return;
    this.timer = setInterval(() => {
      this.tick();
    }, this.updateIntervalMs);
  }

  stopSimulation() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  /**
   * Periodic simulation tick: generates realistic slight micro-fluctuations in speeds
   * and processes incoming probe batches.
   */
  tick() {
    const updatedEdges = [];
    const edges = this.graph.getAllEdges();

    // Randomly select 8-15 edges to update with new telemetry probes
    const sampleCount = Math.floor(Math.random() * 8) + 8;
    for (let i = 0; i < sampleCount; i++) {
      const edge = edges[Math.floor(Math.random() * edges.length)];
      if (!edge) continue;

      // Generate probe speed based on current scenario and base speed
      const targetSpeed = this.computeScenarioTargetSpeed(edge);
      // Small random jitter (-5 to +5 km/h)
      const jitter = (Math.random() * 10) - 5;
      const probeSpeed = Math.max(10, Math.min(edge.freeFlowSpeedKmh * 1.05, targetSpeed + jitter));

      // Apply Exponential Moving Average (EMA) dampening:
      // newSpeed = alpha * probeSpeed + (1 - alpha) * currentSpeed
      const newSpeed = Number((this.dampeningAlpha * probeSpeed + (1 - this.dampeningAlpha) * edge.currentSpeedKmh).toFixed(1));

      const updateResult = this.graph.updateEdgeDynamicWeight(edge.id, {
        currentSpeedKmh: newSpeed
      });

      if (updateResult && updateResult.deltaPercent > 0.05) {
        updatedEdges.push(updateResult);
      }
    }

    this.probesProcessed += Math.floor(this.probeRatePerSec * (this.updateIntervalMs / 1000));

    if (updatedEdges.length > 0) {
      this.emit('traffic_update', {
        timestamp: new Date().toISOString(),
        scenario: this.activeScenario,
        probesProcessed: this.probesProcessed,
        updatedEdgesCount: updatedEdges.length,
        updatedEdges: updatedEdges.map(u => ({
          edgeId: u.edge.id,
          name: u.edge.name,
          currentSpeedKmh: u.edge.currentSpeedKmh,
          congestionFactor: u.edge.congestionFactor,
          travelTimeMin: u.currentTravelTimeMin,
          deltaPercent: Number((u.deltaPercent * 100).toFixed(1))
        }))
      });
    }
  }

  computeScenarioTargetSpeed(edge) {
    let multiplier = 1.0;

    if (this.activeScenario === "chennai_rush_hour") {
      if (edge.from.startsWith("chennai_") || edge.to.startsWith("chennai_") || edge.id.includes("chengalpattu")) {
        multiplier = 0.40; // Severe crawl in Chennai metro
      }
    } else if (this.activeScenario === "festival_exodus") {
      if (edge.id.includes("chengalpattu") || edge.id.includes("tindivanam") || edge.id.includes("villupuram") || edge.id.includes("ulundurpet")) {
        multiplier = 0.35; // Heavy highway outflow
      }
    } else if (this.activeScenario === "monsoon_flooding") {
      if (edge.id.includes("marakkanam") || edge.id.includes("cuddalore") || edge.id.includes("chidambaram") || edge.id.includes("nagapattinam")) {
        multiplier = 0.45; // Waterlogged coastal roads
      }
    }

    return edge.freeFlowSpeedKmh * multiplier;
  }

  setScenario(scenarioId) {
    this.activeScenario = scenarioId;
    // Apply immediate global edge shifts
    const edges = this.graph.getAllEdges();
    const updated = [];

    for (const edge of edges) {
      const targetSpeed = this.computeScenarioTargetSpeed(edge);
      const res = this.graph.updateEdgeDynamicWeight(edge.id, {
        currentSpeedKmh: Number(targetSpeed.toFixed(1))
      });
      if (res) updated.push(res);
    }

    this.emit('scenario_changed', {
      scenarioId,
      updatedCount: updated.length
    });

    return { success: true, scenario: scenarioId, affectedEdges: updated.length };
  }

  /**
   * Add a real-time road incident (accident, flood, roadwork, breakdown)
   */
  addIncident(incident) {
    const id = `inc_${Date.now()}_${this.incidentCounter++}`;
    const newIncident = {
      id,
      edgeId: incident.edgeId,
      type: incident.type || "hazard",
      title: incident.title || "Road Incident",
      description: incident.description || "Unspecified delay reported.",
      delayMin: Number(incident.delayMin || 15),
      lat: incident.lat,
      lng: incident.lng,
      timestamp: new Date().toISOString()
    };

    this.incidents.set(id, newIncident);

    // Update the edge with this incident
    const edge = this.graph.getEdge(incident.edgeId);
    if (edge) {
      const currentEdgeIncidents = edge.incidents || [];
      const updatedList = [...currentEdgeIncidents, newIncident];
      this.graph.updateEdgeDynamicWeight(incident.edgeId, {
        incidents: updatedList
      });

      this.emit('incident_added', { incident: newIncident, edgeId: incident.edgeId });
    }

    return newIncident;
  }

  removeIncident(incidentId) {
    const inc = this.incidents.get(incidentId);
    if (!inc) return false;

    this.incidents.delete(incidentId);
    const edge = this.graph.getEdge(inc.edgeId);
    if (edge) {
      const updatedList = (edge.incidents || []).filter(item => item.id !== incidentId);
      this.graph.updateEdgeDynamicWeight(inc.edgeId, {
        incidents: updatedList
      });
      this.emit('incident_removed', { incidentId, edgeId: inc.edgeId });
    }
    return true;
  }

  getAllIncidents() {
    return Array.from(this.incidents.values());
  }

  /**
   * Ingest a batch of simulated connected vehicle probes
   * (e.g. from Google Maps Android/iOS location probes).
   */
  ingestProbes(probeBatch = []) {
    const results = [];
    for (const probe of probeBatch) {
      const { edgeId, reportedSpeedKmh } = probe;
      const edge = this.graph.getEdge(edgeId);
      if (!edge) continue;

      // Apply EMA smoothing
      const newSpeed = Number((this.dampeningAlpha * reportedSpeedKmh + (1 - this.dampeningAlpha) * edge.currentSpeedKmh).toFixed(1));
      const res = this.graph.updateEdgeDynamicWeight(edgeId, { currentSpeedKmh: newSpeed });
      if (res) results.push(res);
    }

    this.probesProcessed += probeBatch.length;
    this.emit('probes_ingested', { count: probeBatch.length, timestamp: new Date().toISOString() });
    return results;
  }

  getTelemetrySummary() {
    return {
      activeScenario: this.activeScenario,
      totalIncidents: this.incidents.size,
      probesProcessed: this.probesProcessed,
      probeStreamRate: `${this.probeRatePerSec} probes/sec`,
      dampeningAlpha: this.dampeningAlpha,
      isSimulationRunning: this.timer !== null
    };
  }
}

module.exports = { TrafficEngine };
