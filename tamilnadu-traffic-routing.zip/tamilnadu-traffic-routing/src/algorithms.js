/**
 * Pathfinding Algorithms for Dynamic Road Networks:
 * - Binary Min-Priority Queue
 * - Dijkstra's Distance-Optimal Path
 * - Dynamic Time-Optimal A* with Admissible Haversine Heuristic
 * - K-Shortest / Alternative Corridor Finder (Yen's Variant)
 * - Navigation Turn-by-Turn & Trip Economics Estimator
 */

const { haversineDistance } = require('./graph');

class MinPriorityQueue {
  constructor() {
    this.heap = [];
  }

  size() {
    return this.heap.length;
  }

  isEmpty() {
    return this.heap.length === 0;
  }

  push(item, priority) {
    this.heap.push({ item, priority });
    this._bubbleUp(this.heap.length - 1);
  }

  pop() {
    if (this.isEmpty()) return null;
    const top = this.heap[0];
    const bottom = this.heap.pop();
    if (!this.isEmpty()) {
      this.heap[0] = bottom;
      this._sinkDown(0);
    }
    return top.item;
  }

  _bubbleUp(idx) {
    while (idx > 0) {
      const parentIdx = Math.floor((idx - 1) / 2);
      if (this.heap[idx].priority < this.heap[parentIdx].priority) {
        const tmp = this.heap[idx];
        this.heap[idx] = this.heap[parentIdx];
        this.heap[parentIdx] = tmp;
        idx = parentIdx;
      } else {
        break;
      }
    }
  }

  _sinkDown(idx) {
    const length = this.heap.length;
    while (true) {
      let leftChildIdx = 2 * idx + 1;
      let rightChildIdx = 2 * idx + 2;
      let swapIdx = null;

      if (leftChildIdx < length) {
        if (this.heap[leftChildIdx].priority < this.heap[idx].priority) {
          swapIdx = leftChildIdx;
        }
      }

      if (rightChildIdx < length) {
        const compareIdx = swapIdx === null ? idx : leftChildIdx;
        if (this.heap[rightChildIdx].priority < this.heap[compareIdx].priority) {
          swapIdx = rightChildIdx;
        }
      }

      if (swapIdx === null) break;
      const tmp = this.heap[idx];
      this.heap[idx] = this.heap[swapIdx];
      this.heap[swapIdx] = tmp;
      idx = swapIdx;
    }
  }
}

/**
 * Dijkstra's Algorithm (Distance-Optimal Shortest Path)
 * Weights edges purely by road distance in km.
 */
function dijkstraShortestPath(graph, startId, goalId) {
  const startTime = performance.now();
  const startNode = graph.getNode(startId);
  const goalNode = graph.getNode(goalId);

  if (!startNode || !goalNode) {
    throw new Error(`Invalid start or goal node: ${startId} -> ${goalId}`);
  }

  const distances = new Map();
  const previous = new Map(); // nodeId -> { fromNode, edge }
  const visited = new Set();
  const pq = new MinPriorityQueue();
  let heapOperations = 0;

  for (const node of graph.getAllNodes()) {
    distances.set(node.id, Infinity);
  }

  distances.set(startId, 0);
  pq.push(startId, 0);
  heapOperations++;

  while (!pq.isEmpty()) {
    const currentId = pq.pop();
    heapOperations++;

    if (visited.has(currentId)) continue;
    visited.add(currentId);

    if (currentId === goalId) break;

    const currentDist = distances.get(currentId);
    const outgoing = graph.getOutgoingEdges(currentId);

    for (const edge of outgoing) {
      const neighborId = edge.to;
      if (visited.has(neighborId)) continue;

      const newDist = currentDist + edge.distanceKm;
      if (newDist < distances.get(neighborId)) {
        distances.set(neighborId, newDist);
        previous.set(neighborId, { fromNode: currentId, edge });
        pq.push(neighborId, newDist);
        heapOperations++;
      }
    }
  }

  const runtimeMs = Number((performance.now() - startTime).toFixed(3));

  if (!visited.has(goalId)) {
    return {
      found: false,
      algorithm: "Dijkstra (Distance-Optimal)",
      runtimeMs,
      nodesVisited: visited.size,
      heapOperations
    };
  }

  // Reconstruct path
  return reconstructRouteDetails(graph, startId, goalId, previous, "Dijkstra (Shortest Distance)", runtimeMs, visited.size, heapOperations);
}

/**
 * Dynamic A* Pathfinding (Time-Optimal Fastest Path)
 * Dynamic edge weight = current travel time in minutes.
 * Admissible Heuristic: h(u) = (Haversine(u, goal) / maxHighwaySpeed) * 60 minutes.
 */
function aStarFastestPath(graph, startId, goalId) {
  const startTime = performance.now();
  const startNode = graph.getNode(startId);
  const goalNode = graph.getNode(goalId);

  if (!startNode || !goalNode) {
    throw new Error(`Invalid start or goal node: ${startId} -> ${goalId}`);
  }

  const maxSpeed = graph.meta.maxHighwaySpeed || 100; // km/h
  const heuristic = (nodeId) => {
    const n = graph.getNode(nodeId);
    const airDistKm = haversineDistance(n.lat, n.lng, goalNode.lat, goalNode.lng);
    // Admissible: underestimates or equals true minimum travel time
    return (airDistKm / maxSpeed) * 60;
  };

  const gScore = new Map(); // Best known travel time from start
  const fScore = new Map(); // gScore + heuristic
  const previous = new Map();
  const visited = new Set();
  const pq = new MinPriorityQueue();
  let heapOperations = 0;

  for (const node of graph.getAllNodes()) {
    gScore.set(node.id, Infinity);
    fScore.set(node.id, Infinity);
  }

  gScore.set(startId, 0);
  const startH = heuristic(startId);
  fScore.set(startId, startH);
  pq.push(startId, startH);
  heapOperations++;

  while (!pq.isEmpty()) {
    const currentId = pq.pop();
    heapOperations++;

    if (visited.has(currentId)) continue;
    visited.add(currentId);

    if (currentId === goalId) break;

    const currentG = gScore.get(currentId);
    const outgoing = graph.getOutgoingEdges(currentId);

    for (const edge of outgoing) {
      const neighborId = edge.to;
      if (visited.has(neighborId)) continue;

      // Real-time dynamic edge weight: travel time in minutes
      const tentativeG = currentG + edge.currentTravelTimeMin;

      if (tentativeG < gScore.get(neighborId)) {
        gScore.set(neighborId, tentativeG);
        const h = heuristic(neighborId);
        fScore.set(neighborId, tentativeG + h);
        previous.set(neighborId, { fromNode: currentId, edge });
        pq.push(neighborId, tentativeG + h);
        heapOperations++;
      }
    }
  }

  const runtimeMs = Number((performance.now() - startTime).toFixed(3));

  if (!visited.has(goalId)) {
    return {
      found: false,
      algorithm: "A* (Dynamic Time-Optimal)",
      runtimeMs,
      nodesVisited: visited.size,
      heapOperations
    };
  }

  return reconstructRouteDetails(graph, startId, goalId, previous, "Dynamic A* (Fastest Route)", runtimeMs, visited.size, heapOperations);
}

/**
 * Reconstruct route details, geometry coordinates, traffic segments, and metrics.
 */
function reconstructRouteDetails(graph, startId, goalId, previousMap, algorithmName, runtimeMs, nodesVisited, heapOperations) {
  const pathNodes = [];
  const edgesTraversed = [];
  let curr = goalId;

  while (curr !== startId) {
    pathNodes.unshift(curr);
    const step = previousMap.get(curr);
    if (!step) break;
    edgesTraversed.unshift(step.edge);
    curr = step.fromNode;
  }
  pathNodes.unshift(startId);

  // Compute aggregated properties
  let totalDistanceKm = 0;
  let totalTravelTimeMin = 0;
  let totalFreeFlowTimeMin = 0;
  let totalTollDelayMin = 0;
  let totalIncidentDelayMin = 0;
  const tollsEncountered = [];
  const activeIncidents = [];
  const fullGeometry = [];
  const segmentBreakdown = [];

  for (let i = 0; i < edgesTraversed.length; i++) {
    const e = edgesTraversed[i];
    totalDistanceKm += e.distanceKm;
    totalTravelTimeMin += e.currentTravelTimeMin;
    totalFreeFlowTimeMin += e.baseTravelTimeMin;
    totalTollDelayMin += (e.tollDelayMin || 0);
    totalIncidentDelayMin += (e.incidentDelayMin || 0);

    if (e.tolls && e.tolls.length > 0) {
      tollsEncountered.push(...e.tolls);
    }
    if (e.incidents && e.incidents.length > 0) {
      activeIncidents.push(...e.incidents);
    }

    // Geometry stitching
    if (e.geometry && e.geometry.length > 0) {
      if (fullGeometry.length > 0) {
        fullGeometry.push(...e.geometry.slice(1));
      } else {
        fullGeometry.push(...e.geometry);
      }
    }

    const { status, color, code } = require('./graph').RoadGraph.getCongestionStatus(e.congestionFactor);

    segmentBreakdown.push({
      edgeId: e.id,
      from: e.from,
      to: e.to,
      fromName: e.fromName,
      toName: e.toName,
      name: e.name,
      category: e.category,
      distanceKm: e.distanceKm,
      freeFlowSpeedKmh: e.freeFlowSpeedKmh,
      currentSpeedKmh: e.currentSpeedKmh,
      congestionFactor: e.congestionFactor,
      congestionStatus: status,
      congestionColor: color,
      congestionCode: code,
      travelTimeMin: e.currentTravelTimeMin,
      tollDelayMin: e.tollDelayMin || 0,
      incidentDelayMin: e.incidentDelayMin || 0,
      tolls: e.tolls || [],
      incidents: e.incidents || [],
      geometry: e.geometry
    });
  }

  totalDistanceKm = Number(totalDistanceKm.toFixed(1));
  totalTravelTimeMin = Number(totalTravelTimeMin.toFixed(1));
  totalFreeFlowTimeMin = Number(totalFreeFlowTimeMin.toFixed(1));
  const trafficDelayMin = Math.max(0, Number((totalTravelTimeMin - totalFreeFlowTimeMin).toFixed(1)));

  // Trip economics (fuel, fastag, emissions)
  const economics = estimateTripEconomics(totalDistanceKm, totalTravelTimeMin, tollsEncountered);

  // Turn-by-turn guidance
  const directions = generateTurnByTurnDirections(graph, pathNodes, edgesTraversed);

  // Bounding box for spatial caching and map fit
  let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
  for (const pt of fullGeometry) {
    if (pt[0] < minLat) minLat = pt[0];
    if (pt[0] > maxLat) maxLat = pt[0];
    if (pt[1] < minLng) minLng = pt[1];
    if (pt[1] > maxLng) maxLng = pt[1];
  }

  return {
    found: true,
    algorithm: algorithmName,
    origin: graph.getNode(startId),
    destination: graph.getNode(goalId),
    pathNodeIds: pathNodes,
    pathNodeNames: pathNodes.map(id => graph.getNode(id).name),
    edgeIds: edgesTraversed.map(e => e.id),
    totalDistanceKm,
    totalTravelTimeMin,
    totalFreeFlowTimeMin,
    trafficDelayMin,
    formattedETA: formatMinutes(totalTravelTimeMin),
    formattedFreeFlowETA: formatMinutes(totalFreeFlowTimeMin),
    averageSpeedKmh: Number(((totalDistanceKm / (totalTravelTimeMin / 60))).toFixed(1)),
    tollsEncountered,
    activeIncidents,
    economics,
    directions,
    segmentBreakdown,
    geometry: fullGeometry,
    bounds: [[minLat, minLng], [maxLat, maxLng]],
    telemetry: {
      runtimeMs,
      nodesVisited,
      heapOperations,
      edgesExplored: edgesTraversed.length
    }
  };
}

/**
 * Format minutes into readable "X hrs Y mins"
 */
function formatMinutes(minutes) {
  const hrs = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  if (hrs === 0) return `${mins} min`;
  return `${hrs} hr ${mins > 0 ? mins + ' min' : ''}`;
}

/**
 * Generates turn-by-turn navigation instructions.
 */
function generateTurnByTurnDirections(graph, nodeIds, edges) {
  const directions = [];
  const startNode = graph.getNode(nodeIds[0]);
  directions.push({
    step: 1,
    type: "depart",
    instruction: `Depart from ${startNode.name}`,
    road: edges[0] ? edges[0].name : "Starting Road",
    distanceKm: 0,
    cumulativeKm: 0
  });

  let cumulativeKm = 0;
  for (let i = 0; i < edges.length; i++) {
    const e = edges[i];
    cumulativeKm += e.distanceKm;
    const targetNode = graph.getNode(e.to);

    let instruction = `Continue on ${e.name} towards ${targetNode.name}`;
    let type = "continue";

    if (e.category === "Expressway") {
      instruction = `Join expressway ${e.name} toward ${targetNode.name}`;
      type = "highway";
    }

    if (e.tolls && e.tolls.length > 0) {
      instruction += ` (Pass ${e.tolls.map(t => t.name).join(", ")})`;
    }

    directions.push({
      step: i + 2,
      type,
      instruction,
      road: e.name,
      distanceKm: e.distanceKm,
      travelTimeMin: e.currentTravelTimeMin,
      cumulativeKm: Number(cumulativeKm.toFixed(1))
    });
  }

  const endNode = graph.getNode(nodeIds[nodeIds.length - 1]);
  directions.push({
    step: directions.length + 1,
    type: "arrive",
    instruction: `Arrive at destination: ${endNode.name}`,
    road: "Destination",
    distanceKm: 0,
    cumulativeKm: Number(cumulativeKm.toFixed(1))
  });

  return directions;
}

/**
 * Estimate fuel consumption, FASTag cost, and carbon emissions.
 */
function estimateTripEconomics(distanceKm, travelTimeMin, tolls) {
  // Baseline highway efficiency: 16 km/liter. If average speed is low (crawling traffic), fuel efficiency drops.
  const avgSpeed = (distanceKm / (travelTimeMin / 60));
  let efficiencyKmPerL = 16.0;
  if (avgSpeed < 35) efficiencyKmPerL = 10.5; // Heavy congestion penalty
  else if (avgSpeed < 55) efficiencyKmPerL = 13.0;

  const fuelLiters = Number((distanceKm / efficiencyKmPerL).toFixed(1));
  const petrolPriceTamilNadu = 101.5; // INR / liter
  const estimatedFuelCostInr = Math.round(fuelLiters * petrolPriceTamilNadu);

  // Toll plaza FASTag fee (approx 95 INR per major highway toll)
  const tollCount = tolls.length;
  const estimatedTollCostInr = tollCount * 95;

  // CO2 footprint: ~2.31 kg CO2 per liter of petrol
  const co2Kg = Number((fuelLiters * 2.31).toFixed(1));

  return {
    fuelLiters,
    estimatedFuelCostInr,
    tollCount,
    estimatedTollCostInr,
    totalTripCostInr: estimatedFuelCostInr + estimatedTollCostInr,
    co2Kg
  };
}

/**
 * Alternative Corridors Finder (Yen's K-Shortest Path Variant)
 * Returns the primary fastest route, the shortest physical distance route,
 * and up to 2 distinct alternative corridors.
 */
function findMultiRouteAlternatives(graph, startId, goalId) {
  const fastest = aStarFastestPath(graph, startId, goalId);
  const shortest = dijkstraShortestPath(graph, startId, goalId);

  if (!fastest.found) {
    return { primary: fastest, alternatives: [], shortest: shortest };
  }

  const routes = [
    {
      ...fastest,
      routeTag: "Fastest Route",
      tagColor: "#10B981",
      badge: "RECOMMENDED",
      isPrimary: true
    }
  ];

  // If shortest route has significantly different edges, include it as a distinct alternative
  const fastestEdgeSet = new Set(fastest.edgeIds);
  const shortestEdgeSet = new Set(shortest.edgeIds);
  const overlap = [...shortestEdgeSet].filter(x => fastestEdgeSet.has(x)).length;
  const overlapRatio = overlap / Math.max(shortestEdgeSet.size, 1);

  if (overlapRatio < 0.85) {
    shortest.routeTag = "Shortest Distance";
    shortest.tagColor = "#3B82F6";
    shortest.badge = "SHORTEST";
    shortest.timeDeltaMin = Number((shortest.totalTravelTimeMin - fastest.totalTravelTimeMin).toFixed(1));
  }

  // Generate 2nd and 3rd alternative corridors using edge penalty branching
  const usedEdges = new Set(fastest.edgeIds);
  const penalizedGraph = graph.cloneWithEdgePenalty(usedEdges, 3.5);
  const alt2 = aStarFastestPath(penalizedGraph, startId, goalId);

  if (alt2.found && alt2.edgeIds.join() !== fastest.edgeIds.join()) {
    alt2.routeTag = "Alternative Corridor";
    alt2.tagColor = "#8B5CF6";
    alt2.badge = `+${Math.max(1, Math.round(alt2.totalTravelTimeMin - fastest.totalTravelTimeMin))} min`;
    alt2.timeDeltaMin = Number((alt2.totalTravelTimeMin - fastest.totalTravelTimeMin).toFixed(1));
    routes.push(alt2);
  }

  return {
    primary: routes[0],
    alternatives: routes.slice(1),
    shortest: shortest
  };
}

module.exports = {
  MinPriorityQueue,
  dijkstraShortestPath,
  aStarFastestPath,
  findMultiRouteAlternatives,
  estimateTripEconomics,
  formatMinutes
};
