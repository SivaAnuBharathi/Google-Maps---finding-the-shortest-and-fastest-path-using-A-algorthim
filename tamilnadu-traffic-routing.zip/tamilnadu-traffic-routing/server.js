/**
 * Tamil Nadu Dynamic Graph Routing & Pathfinding Server
 * Full-stack Google Maps routing simulation engine with:
 * - Real-time traffic re-weighting
 * - Intelligent surgical cache invalidation
 * - Dynamic mid-journey rerouting
 * - REST & WebSocket APIs
 */

const http = require('http');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { WebSocketServer, WebSocket } = require('ws');

const { RoadGraph } = require('./src/graph');
const { aStarFastestPath, dijkstraShortestPath, findMultiRouteAlternatives } = require('./src/algorithms');
const { TrafficEngine } = require('./src/trafficEngine');
const { RouteCacheManager } = require('./src/cacheManager');
const { TripSimulator } = require('./src/tripSimulator');

// Load Tamil Nadu road network and presets
const networkData = require('./data/tn_network.json');
const presetsData = require('./data/presets.json');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Core Engine Singletons
const roadGraph = new RoadGraph(networkData);
const cacheManager = new RouteCacheManager({
  maxEntries: 250,
  defaultTtlMs: 120000, // 2 minutes
  invalidationThresholdPercent: 10.0
});
const trafficEngine = new TrafficEngine(roadGraph, { updateIntervalMs: 3500 });
const tripSimulator = new TripSimulator(roadGraph, { rerouteThresholdMin: 6.0 });

// Broadcast helper for WebSockets
function broadcast(eventType, payload) {
  const message = JSON.stringify({ type: eventType, data: payload, timestamp: new Date().toISOString() });
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// Wire Traffic Engine events to Cache Invalidator & WebSocket Clients
trafficEngine.on('traffic_update', (update) => {
  // Check each updated edge for surgical cache invalidation
  for (const item of update.updatedEdges) {
    const deltaRatio = (item.deltaPercent || 0) / 100;
    cacheManager.onEdgeTrafficChanged(
      item.edgeId,
      deltaRatio,
      item.travelTimeMin,
      `Telemetry shift (${item.currentSpeedKmh} km/h)`
    );
  }

  broadcast('TRAFFIC_UPDATE', update);
});

trafficEngine.on('incident_added', ({ incident, edgeId }) => {
  const edge = roadGraph.getEdge(edgeId);
  const deltaRatio = edge ? (incident.delayMin / Math.max(1, edge.currentTravelTimeMin)) : 0.25;
  cacheManager.onEdgeTrafficChanged(edgeId, deltaRatio, edge ? edge.currentTravelTimeMin : 30, `Incident: ${incident.title}`);

  broadcast('INCIDENT_ADDED', { incident, edgeId });
});

trafficEngine.on('incident_removed', ({ incidentId, edgeId }) => {
  const edge = roadGraph.getEdge(edgeId);
  cacheManager.onEdgeTrafficChanged(edgeId, 0.2, edge ? edge.currentTravelTimeMin : 30, "Incident cleared");
  broadcast('INCIDENT_REMOVED', { incidentId, edgeId });
});

trafficEngine.on('scenario_changed', (info) => {
  cacheManager.clear(); // Complete traffic scenario shift requires cache refresh
  broadcast('SCENARIO_CHANGED', info);
});

// Wire Trip Simulator events
tripSimulator.onUpdateCallback = (tripStatus) => {
  broadcast('TRIP_UPDATE', tripStatus);
};

tripSimulator.onRerouteAlertCallback = (alert) => {
  broadcast('REROUTE_ALERT', alert);
};

// Start background traffic probe simulation
trafficEngine.startSimulation();

// ---------------- REST API ROUTES ---------------- //

/**
 * GET /api/network - Get full graph nodes, edges, and metadata
 */
app.get('/api/network', (req, res) => {
  res.json({
    meta: roadGraph.meta,
    nodes: roadGraph.getAllNodes(),
    edges: roadGraph.getAllEdges(),
    incidents: trafficEngine.getAllIncidents()
  });
});

/**
 * GET /api/presets - Get popular Tamil Nadu routes and traffic scenarios
 */
app.get('/api/presets', (req, res) => {
  res.json(presetsData);
});

/**
 * GET /api/route - Main pathfinding endpoint with cache integration
 * Query params: from, to, mode ('fastest' | 'shortest' | 'all')
 */
app.get('/api/route', (req, res) => {
  const { from, to, mode = "all" } = req.query;

  if (!from || !to) {
    return res.status(400).json({ error: "Missing 'from' or 'to' query parameters" });
  }

  if (from === to) {
    return res.status(400).json({ error: "Origin and Destination cannot be the same junction" });
  }

  const queryStartTime = performance.now();

  // 1. Check Route Cache
  const cachedResult = cacheManager.get(from, to, mode);
  if (cachedResult) {
    const totalQueryTimeMs = Number((performance.now() - queryStartTime).toFixed(3));
    return res.json({
      ...cachedResult,
      isFromCache: true,
      queryTimeMs: totalQueryTimeMs,
      cacheStats: cacheManager.getTelemetry()
    });
  }

  // 2. Compute route on cache miss
  let result;
  if (mode === "shortest") {
    result = dijkstraShortestPath(roadGraph, from, to);
  } else if (mode === "fastest") {
    result = aStarFastestPath(roadGraph, from, to);
  } else {
    // Multi-route alternatives (Fastest, Shortest, Alternative Corridors)
    result = findMultiRouteAlternatives(roadGraph, from, to);
  }

  const totalComputeTimeMs = Number((performance.now() - queryStartTime).toFixed(3));

  if (!result || (result.primary && !result.primary.found) || (result.found === false)) {
    return res.status(404).json({ error: "No viable path found between nodes", queryTimeMs: totalComputeTimeMs });
  }

  // 3. Store in surgical cache
  const primaryRoute = result.primary || result;
  cacheManager.set(from, to, mode, result, totalComputeTimeMs);

  res.json({
    ...result,
    isFromCache: false,
    queryTimeMs: totalComputeTimeMs,
    cacheStats: cacheManager.getTelemetry()
  });
});

/**
 * POST /api/traffic/scenario - Set global traffic scenario
 */
app.post('/api/traffic/scenario', (req, res) => {
  const { scenarioId } = req.body;
  if (!scenarioId) {
    return res.status(400).json({ error: "Missing scenarioId" });
  }

  const result = trafficEngine.setScenario(scenarioId);
  res.json(result);
});

/**
 * POST /api/traffic/probes - Ingest batch of vehicle probes
 */
app.post('/api/traffic/probes', (req, res) => {
  const { probes } = req.body;
  if (!Array.isArray(probes)) {
    return res.status(400).json({ error: "Probes must be an array" });
  }

  const result = trafficEngine.ingestProbes(probes);
  res.json({ success: true, count: probes.length, updated: result.length });
});

/**
 * POST /api/incidents - Add live road incident
 */
app.post('/api/incidents', (req, res) => {
  const { edgeId, type, title, description, delayMin, lat, lng } = req.body;
  if (!edgeId) {
    return res.status(400).json({ error: "Missing edgeId" });
  }

  const incident = trafficEngine.addIncident({ edgeId, type, title, description, delayMin, lat, lng });
  res.json({ success: true, incident });
});

/**
 * DELETE /api/incidents/:id - Clear road incident
 */
app.delete('/api/incidents/:id', (req, res) => {
  const success = trafficEngine.removeIncident(req.params.id);
  res.json({ success });
});

/**
 * GET /api/telemetry - Comprehensive telemetry metrics
 */
app.get('/api/telemetry', (req, res) => {
  res.json({
    cache: cacheManager.getTelemetry(),
    traffic: trafficEngine.getTelemetrySummary(),
    trip: tripSimulator.getStatus(),
    graph: {
      totalNodes: roadGraph.nodes.size,
      totalEdges: roadGraph.edges.size
    }
  });
});

/**
 * POST /api/cache/clear - Clear route cache
 */
app.post('/api/cache/clear', (req, res) => {
  cacheManager.clear();
  res.json({ success: true, message: "Route cache cleared" });
});

/**
 * POST /api/simulation/start - Start mid-journey driving simulation
 */
app.post('/api/simulation/start', (req, res) => {
  const { route } = req.body;
  if (!route) {
    return res.status(400).json({ error: "Missing route object" });
  }

  try {
    const status = tripSimulator.startTrip(route);
    res.json({ success: true, status });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/**
 * POST /api/simulation/speed - Set simulation playback speed (1x to 30x)
 */
app.post('/api/simulation/speed', (req, res) => {
  const { multiplier } = req.body;
  tripSimulator.setSimulationSpeed(multiplier);
  res.json({ success: true, speed: `${multiplier}x` });
});

/**
 * POST /api/simulation/reroute - Apply dynamic mid-journey reroute
 */
app.post('/api/simulation/reroute', (req, res) => {
  const { newRoute } = req.body;
  if (!newRoute) {
    return res.status(400).json({ error: "Missing newRoute" });
  }

  const success = tripSimulator.applyReroute(newRoute);
  res.json({ success });
});

/**
 * POST /api/simulation/stop - Stop mid-journey simulation
 */
app.post('/api/simulation/stop', (req, res) => {
  tripSimulator.stopTrip();
  res.json({ success: true, message: "Simulation stopped" });
});

// WebSocket Connection Management
wss.on('connection', (ws) => {
  // Send initial welcome & system state
  ws.send(JSON.stringify({
    type: 'INIT',
    data: {
      telemetry: {
        cache: cacheManager.getTelemetry(),
        traffic: trafficEngine.getTelemetrySummary()
      },
      incidents: trafficEngine.getAllIncidents()
    }
  }));

  ws.on('message', (msgStr) => {
    try {
      const msg = JSON.parse(msgStr);
      if (msg.action === 'PING') {
        ws.send(JSON.stringify({ type: 'PONG' }));
      }
    } catch (e) {
      // Ignore invalid JSON
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🚦 Tamil Nadu Dynamic Graph Routing & Pathfinding Server`);
  console.log(`🌐 Application running at: http://localhost:${PORT}`);
  console.log(`📊 Nodes: ${roadGraph.nodes.size} | Edges: ${roadGraph.edges.size}`);
  console.log(`🛰️ Live Traffic Telemetry & WebSocket Engine Active`);
  console.log(`=======================================================`);
});
